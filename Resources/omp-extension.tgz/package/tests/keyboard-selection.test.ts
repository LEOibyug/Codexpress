import { beforeAll, describe, expect, test } from "bun:test";
import type { ExtensionAPI, ExtensionContext, ExtensionHandler, SessionStartEvent } from "@oh-my-pi/pi-coding-agent";
import { CombinedAutocompleteProvider, ProcessTerminal, TUI } from "@oh-my-pi/pi-tui";
import { KeybindingsManager } from "@oh-my-pi/pi-tui/app-keybindings";
import { CustomEditor } from "@oh-my-pi/pi-tui/prompt/custom-editor";
import { getEditorTheme, initTheme } from "@oh-my-pi/pi-tui/theme";
import { registerKeyboardSelection } from "../src/keyboard-selection.js";

type EditorFactory = NonNullable<ReturnType<ExtensionContext["ui"]["getEditorComponent"]>>;

beforeAll(async () => { await initTheme(false); });

async function session(previous?: EditorFactory) {
	let start: ExtensionHandler<SessionStartEvent> | undefined;
	let factory = previous;
	const api = {
		on(event: string, handler: ExtensionHandler<SessionStartEvent>) {
			if (event !== "session_start") throw new Error(`Unexpected lifecycle event: ${event}`);
			start = handler;
		},
	} as unknown as ExtensionAPI;
	registerKeyboardSelection(api);
	const context = {
		hasUI: true,
		ui: {
			getEditorComponent: () => factory,
			setEditorComponent: (value: EditorFactory | undefined) => { factory = value; },
		},
	} as unknown as ExtensionContext;
	await start!({ type: "session_start" }, context);
	return { factory };
}

async function editorFixture(previous?: EditorFactory) {
	const lifecycle = await session(previous);
	const editor = lifecycle.factory!(new TUI(new ProcessTerminal()), getEditorTheme(), KeybindingsManager.inMemory());
	editor.focused = true;
	editor.setSpellingFeatures({ typoDetection: false, autocorrect: false, autocomplete: "off" });
	editor.setBorderVisible(false);
	editor.setPaddingX(0);
	editor.setPromptGutter(undefined);
	return editor;
}

const shiftLeft = "\x1b[1;2D";
const shiftRight = "\x1b[1;2C";
const shiftUp = "\x1b[1;2A";
const shiftDown = "\x1b[1;2B";
const shiftHome = "\x1b[1;2H";
const shiftEnd = "\x1b[1;2F";
const undo = "\x1f";

describe("keyboard selection on the stock CustomEditor", () => {
	test("preserves action handlers supplied by an earlier editor extension", async () => {
		let escape = 0;
		const previous: EditorFactory = (tui, theme, keys) => {
			const existing = new CustomEditor(tui, theme, keys);
			existing.onEscape = () => { escape++; };
			return existing;
		};
		const editor = await editorFixture(previous);
		editor.handleInput("\x1b");
		expect(escape).toBe(1);
	});

	test("deletes a whole Unicode grapheme and restores the draft with one host undo", async () => {
		const editor = await editorFixture();
		editor.setText("甲e\u0301👨‍👩‍👧‍👦");
		editor.handleInput(shiftLeft);
		editor.handleInput("\x7f");
		expect(editor.getText()).toBe("甲e\u0301");
		editor.handleInput(undo);
		expect(editor.getText()).toBe("甲e\u0301👨‍👩‍👧‍👦");
		editor.moveToMessageEnd();
		editor.handleInput(shiftLeft);
		editor.handleInput(shiftLeft);
		editor.handleInput("替");
		expect(editor.getText()).toBe("甲替");
		editor.handleInput(undo);
		expect(editor.getText()).toBe("甲e\u0301👨‍👩‍👧‍👦");
	});

	test("cuts the selection through the host clipboard and preserves paste and single-step undo", async () => {
		const editor = await editorFixture();
		const clipboard: string[] = [];
		editor.onYank = text => { clipboard.push(text); };
		editor.setText("保留\n剪切👨‍👩‍👧‍👦");
		editor.handleInput(shiftHome);
		editor.handleInput(shiftLeft);
		editor.handleInput("\x1b[120;9u");
		expect(clipboard).toEqual(["\n剪切👨‍👩‍👧‍👦"]);
		expect(editor.getText()).toBe("保留");
		editor.handleInput(`\x1b[200~${clipboard[0]}\x1b[201~`);
		expect(editor.getText()).toBe("保留\n剪切👨‍👩‍👧‍👦");
		editor.handleInput(undo);
		expect(editor.getText()).toBe("保留");
		editor.handleInput(undo);
		expect(editor.getText()).toBe("保留\n剪切👨‍👩‍👧‍👦");
		editor.handleInput("\x1b[120;9u");
		expect(editor.getText()).toBe("保留\n剪切👨‍👩‍👧‍👦");
		expect(clipboard).toHaveLength(1);
	});

	test("selects across newlines, collapses with arrows, and cancels without deleting", async () => {
		const editor = await editorFixture();
		editor.setText("first\n末尾");
		editor.handleInput(shiftHome);
		editor.handleInput(shiftLeft);
		editor.handleInput("\x1b[D");
		expect(editor.getCursor()).toEqual({ line: 0, col: 5 });
		editor.handleInput(shiftRight);
		editor.handleInput(shiftEnd);
		editor.handleInput("\x1b[C");
		expect(editor.getCursor()).toEqual({ line: 1, col: 2 });
		editor.handleInput(shiftHome);
		editor.handleInput("\x1b");
		editor.handleInput("新");
		expect(editor.getText()).toBe("first\n新末尾");
		editor.handleInput(shiftLeft);
		editor.handleInput(shiftLeft);
		editor.handleInput("\x1b[3~");
		expect(editor.getText()).toBe("first末尾");
	});

	test("supports both word-selection modifiers, Home/End, and super+A without changing Ctrl+A", async () => {
		const editor = await editorFixture();
		editor.setText("one two three");
		editor.handleInput("\x1b[1;6D");
		editor.handleInput("\x7f");
		expect(editor.getText()).toBe("one two ");
		editor.handleInput(undo);
		editor.moveToMessageEnd();
		editor.handleInput("\x1b[1;4D");
		editor.handleInput("3");
		expect(editor.getText()).toBe("one two 3");
		editor.handleInput("\x01");
		editor.handleInput(shiftEnd);
		editor.handleInput("line");
		expect(editor.getText()).toBe("line");
		editor.setText("first\nsecond");
		editor.handleInput("\x01");
		expect(editor.getCursor()).toEqual({ line: 1, col: 0 });
		editor.handleInput("\x1b[97;9u");
		editor.handleInput("\x7f");
		expect(editor.getText()).toBe("");
		editor.handleInput(undo);
		expect(editor.getText()).toBe("first\nsecond");
	});

	test("uses stock wrapped visual rows and does not browse history at selection boundaries", async () => {
		const editor = await editorFixture();
		editor.addToHistory("older prompt");
		editor.setText("abcdefghij");
		editor.render(5);
		editor.handleInput(shiftUp);
		expect(editor.getCursor()).toEqual({ line: 0, col: 4 });
		editor.handleInput(shiftUp);
		expect(editor.getCursor()).toEqual({ line: 0, col: 4 });
		expect(editor.getText()).toBe("abcdefghij");
		editor.handleInput("\x7f");
		expect(editor.getText()).toBe("abcd");
		editor.handleInput(undo);
		expect(editor.getText()).toBe("abcdefghij");
		editor.moveToMessageStart();
		editor.handleInput(shiftDown);
		expect(editor.getCursor()).toEqual({ line: 0, col: 5 });
		editor.handleInput("\x7f");
		expect(editor.getText()).toBe("fghij");
		editor.setText("");
		editor.handleInput(shiftUp);
		expect(editor.getText()).toBe("");
		editor.handleInput("\x1b[A");
		expect(editor.getText()).toBe("older prompt");
	});

	test("keeps attachment labels and their expansions intact across selection delete and undo", async () => {
		const editor = await editorFixture();
		editor.insertTextAttachment("line one\nline two");
		const draft = editor.getText();
		const expanded = editor.getExpandedText();
		editor.moveToMessageStart();
		editor.handleInput(shiftRight);
		editor.handleInput("\x7f");
		expect(editor.getText().trim()).toBe("");
		editor.handleInput(undo);
		expect(editor.getText()).toBe(draft);
		expect(editor.getExpandedText()).toBe(expanded);
	});

	test("replaces selections on split bracketed paste and retains stock collapsed-paste undo semantics", async () => {
		const editor = await editorFixture();
		editor.setText("old");
		editor.handleInput(shiftHome);
		editor.handleInput("\x1b[200~");
		editor.handleInput("new ");
		editor.handleInput("text\x1b[201~");
		expect(editor.getText()).toBe("new text");
		editor.handleInput(undo);
		expect(editor.getText()).toBe("");
		editor.handleInput(undo);
		expect(editor.getText()).toBe("old");
		editor.moveToMessageEnd();
		editor.handleInput(shiftHome);
		const payload = "长".repeat(1001);
		editor.handleInput(`\x1b[200~${payload}\x1b[201~`);
		expect(editor.getExpandedText()).toBe(payload);
		editor.handleInput(shiftHome);
		editor.handleInput("\x7f");
		expect(editor.getText()).toBe("");
		editor.handleInput(undo);
		expect(editor.getExpandedText()).toBe(payload);
	});

	test("selection dismisses real slash autocomplete without stealing its normal Tab completion", async () => {
		const editor = await editorFixture();
		const updated = Promise.withResolvers<void>();
		editor.onAutocompleteUpdate = () => updated.resolve();
		editor.setAutocompleteProvider(new CombinedAutocompleteProvider([{ name: "hello", description: "Greeting" }]));
		for (const key of ["/", "h", "e"]) editor.handleInput(key);
		await updated.promise;
		expect(editor.isShowingAutocomplete()).toBe(true);
		editor.handleInput(shiftLeft);
		expect(editor.isShowingAutocomplete()).toBe(false);
		editor.handleInput("\x1b");
		editor.handleInput("\x1b[F");
		const reopened = Promise.withResolvers<void>();
		editor.onAutocompleteUpdate = () => reopened.resolve();
		editor.handleInput("\t");
		await reopened.promise;
		editor.handleInput("\t");
		expect(editor.getText()).toBe("/hello ");
	});

	test("does not retain stale selection after a host edit or consume ordinary editor actions", async () => {
		const editor = await editorFixture();
		const submissions: string[] = [];
		editor.onSubmit = text => { submissions.push(text); };
		editor.setText("before");
		editor.handleInput(shiftHome);
		editor.setText("after");
		editor.handleInput("!");
		expect(editor.getText()).toBe("after!");
		editor.handleInput("\r");
		expect(submissions).toEqual(["after!"]);
		editor.setVimMode(true);
		editor.handleInput("\x1b");
		expect(editor.vimMode).toBe("normal");
		editor.handleInput(shiftLeft);
		expect(editor.vimMode).toBe("normal");
	});
});
