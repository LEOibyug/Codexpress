import { afterEach, describe, expect, spyOn, test } from "bun:test";
import { chmod, mkdir, mkdtemp, readFile, rm, symlink, writeFile } from "node:fs/promises";
import { createServer } from "node:net";
import type { Server } from "node:net";
import { join } from "node:path";
import { createConnectionResolver, discoverGatewayModels, fetchBudgetRevision } from "../src/connection.js";
import { createProviderModels, parseGatewayModels } from "../src/models.js";
import type { ExtensionAPI, ExtensionCommandContext } from "@oh-my-pi/pi-coding-agent";
import { createCodexpressUsageProvider, type SourceStatus } from "../src/usage.js";
import { registerCodexpressCommands } from "../src/commands.js";
import { formatUsageBreakdown } from "@oh-my-pi/pi-coding-agent/cli/usage-cli";

const cleanup: Array<() => Promise<void>> = [];
const savedEnv = { ...process.env };
afterEach(async () => {
	for (const dispose of cleanup.splice(0).reverse()) await dispose();
	for (const name of ["CODEXPRESS_STATE_DIR", "CODEXPRESS_BASE_URL", "CODEXPRESS_OMP_BASE_URL", "CODEXPRESS_API_KEY"]) {
		if (savedEnv[name] === undefined) delete process.env[name];
		else process.env[name] = savedEnv[name];
	}
});

async function fixture() {
	await mkdir(join(import.meta.dir, "../.runtime/tmp"), { recursive: true });
	const directory = await mkdtemp(join(import.meta.dir, "../.runtime/tmp/core-"));
	cleanup.push(() => rm(directory, { recursive: true, force: true }));
	delete process.env.CODEXPRESS_BASE_URL;
	delete process.env.CODEXPRESS_OMP_BASE_URL;
	delete process.env.CODEXPRESS_API_KEY;
	process.env.CODEXPRESS_STATE_DIR = directory;
	return directory;
}

async function listen(server: Server, path: string) {
	const ready = Promise.withResolvers<void>();
	server.once("error", ready.reject);
	server.listen(path, ready.resolve);
	await ready.promise;
	cleanup.push(async () => {
		const closed = Promise.withResolvers<void>();
		server.close(error => error ? closed.reject(error) : closed.resolve());
		await closed.promise;
	});
}

describe("Codexpress independent provider core", () => {
	test("real Unix binding preserves a prior successful login after failed rebind and refreshes port/key", async () => {
		const directory = await fixture();
		let failBind = false;
		let port = 17001;
		let key = "fixture-original-key";
		const operations: string[] = [];
		const server = createServer(socket => {
			socket.setEncoding("utf8");
			let buffer = "";
			socket.on("data", chunk => {
				buffer += chunk;
				if (!buffer.includes("\n")) return;
				const request = JSON.parse(buffer);
				operations.push(request.op);
				if (request.op === "omp.budgets.revision") {
					socket.end(`${JSON.stringify({ id: request.id, ok: true, data: { revision: "fixture-budget-version" } })}\n`);
					return;
				}
				const data = { provider: "codexpress", api: "openai-codex-responses", base_url: `http://127.0.0.1:${port}/omp/v1`, key,
					enabled: true, running: true, models: [{ id: "fixture-model", context_window: 8000, max_output_tokens: 1000 }],
					capabilities: { websocket: false, remote_compaction_v2: null } };
				socket.end(`${JSON.stringify({ id: request.id, ok: !(failBind && request.op === "omp.bind"), data, error: "请先解锁 Codexpress" })}\n`);
			});
		});
		await listen(server, join(directory, "control.sock"));
		const resolver = createConnectionResolver(join(directory, "profile"));
		const original = await resolver.resolveConnection({ activate: true });
		expect(original.key).toBe("fixture-original-key");
		const beforeProbe = operations.length;
		expect(await fetchBudgetRevision(original)).toBe("fixture-budget-version");
		expect(operations.slice(beforeProbe)).toEqual(["omp.budgets.revision"]);
		failBind = true;
		port = 17002;
		key = "fixture-rotated-key";
		await expect(resolver.resolveConnection({ activate: true })).rejects.toThrow("请先解锁 Codexpress");
		expect(await resolver.resolveConnection()).toEqual(original);
		resolver.invalidate();
		const refreshed = await resolver.resolveConnection({ key: "host-stored-identity" });
		expect(refreshed.baseUrl).toBe("http://127.0.0.1:17002/omp/v1");
		expect(refreshed.key).toBe("host-stored-identity");
		expect((await resolver.resolveConnection()).key).toBe("fixture-rotated-key");
	});

	test("remote credentials remain host-owned while endpoint preference and native model capabilities are retained", async () => {
		const directory = await fixture();
		let expectedKey = "fixture-remote-key";
		const server = Bun.serve({
			hostname: "127.0.0.1", port: 0,
			fetch(request) {
				if (request.headers.get("authorization") !== `Bearer ${expectedKey}`) return new Response(null, { status: 401 });
				return Response.json({ data: [
					{ id: "fixture-remote-chat", kind: "text", context_window: 24000, max_output_tokens: 4000, reasoning: true },
					{ id: "fixture-remote-image", kind: "image", input: ["text", "image"] },
				] });
			},
		});
		cleanup.push(async () => { await server.stop(true); });
		process.env.CODEXPRESS_BASE_URL = `http://127.0.0.1:${server.port}/omp/v1/`;
		process.env.CODEXPRESS_API_KEY = expectedKey;
		const profile = join(directory, "profile");
		const retained = { stateDir: directory, future: { enabled: false, tags: ["保留", 3] }, extra: null };
		await mkdir(profile, { recursive: true });
		await writeFile(join(profile, "codexpress.json"), JSON.stringify({ ...retained, baseUrl: "http://127.0.0.1:1/ignored" }));
		const { resolveConnection } = createConnectionResolver(profile);
		const connection = await resolveConnection({ activate: true });
		const configText = await readFile(join(profile, "codexpress.json"), "utf8");
		expect(configText).not.toContain(expectedKey);
		expect(JSON.parse(configText)).toEqual({ ...retained, baseUrl: connection.baseUrl });
		expectedKey = "host-credential-for-discovery";
		const explicit = await resolveConnection({ key: expectedKey });
		expect(explicit.key).toBe(expectedKey);
		const models = createProviderModels(await discoverGatewayModels(explicit), explicit);
		expect(models[0]).toMatchObject({ kind: "chat", contextWindow: 24000, maxTokens: 4000, preferWebsockets: false,
			remoteCompaction: { enabled: true, v2StreamingEnabled: true,
				v2Endpoint: `${connection.baseUrl}/codex/responses`, endpoint: `${connection.baseUrl}/codex/responses/compact` } });
		expect(models[1]?.kind).toBe("image");
		delete process.env.CODEXPRESS_BASE_URL;
		expect((await createConnectionResolver(profile).resolveConnection({ key: expectedKey })).baseUrl).toBe(connection.baseUrl);
	});

	test("status transport preserves real quota and carries reference only on known official weekly windows", async () => {
		const now = 2_000_000_000_000;
		const clock = spyOn(Date, "now").mockReturnValue(now);
		cleanup.push(async () => { clock.mockRestore(); });
		const halfway = now / 1_000 + 302_400;
		const cases = [
			{ kind: "official", duration: 604800, reset: now / 1_000 + 151_200, ref: 1, expected: ["ref 25.0%"] },
			{ kind: "official", duration: 604800, reset: 1, ref: 42, expected: ["ref 0.0%"] },
			{ kind: "official", duration: 604800, reset: now / 1_000 + 1_209_600, ref: 42, expected: ["ref 100.0%"] },
			{ kind: "official", duration: 604800, reset: undefined, ref: 42.3, expected: ["ref 42.3%"] },
			{ kind: "official", duration: 604800, reset: 0, ref: 101, expected: undefined },
			{ kind: "official", duration: 604800, reset: undefined, ref: null, expected: undefined },
			{ kind: "official", duration: 18000, reset: halfway, ref: 42, expected: undefined },
			{ kind: "official", duration: undefined, reset: halfway, ref: 42, expected: undefined },
			{ kind: "api", duration: 604800, reset: halfway, ref: 42, expected: undefined },
			{ kind: "official", name: "review:secondary", duration: 604800, reset: halfway, ref: 1, expected: ["ref 50.0%"] },
		];
		let requests = 0;
		const server = Bun.serve({ hostname: "127.0.0.1", port: 0, fetch(request) {
			requests++;
			expect(new URL(request.url).pathname + new URL(request.url).search).toBe("/omp/v1/status?include_usage=false");
			expect(request.headers.get("authorization")).toBe("Bearer fixture-only-key");
			return Response.json({ sources: cases.map((item, index) => ({ id: String(index), name: "fixture", kind: item.kind,
				quota: { windows: [{ name: "name" in item ? item.name : "primary", used_percent: 80, window_seconds: item.duration, reset_at: item.reset, ref_cost: item.ref }] } })) });
		} });
		cleanup.push(async () => { await server.stop(true); });
		const provider = createCodexpressUsageProvider(async () => ({ local: false, baseUrl: `http://127.0.0.1:${server.port}/omp/v1` }));
		const report = await provider.fetchUsage({ provider: "codexpress", credential: { type: "api_key", apiKey: "fixture-only-key" } }, { fetch });
		expect(requests).toBe(1);
		expect(formatUsageBreakdown([JSON.parse(JSON.stringify(report))], [], Date.now())).toContain("ref 42.3%");
		expect(report?.limits).toHaveLength(cases.length);
		for (const [index, item] of cases.entries()) {
			const limit = report!.limits[index]!;
			expect(limit.amount).toEqual({ used: 80, remaining: 20, unit: "percent" });
			expect(limit.status).toBe("ok");
			if (item.expected) expect(limit.label).toContain(item.expected[0]!);
			else expect(limit.label).not.toContain("ref ");
			expect(limit.notes).toBeUndefined();
			expect(limit.window?.label).toBe("name" in item ? "review · 周额度" : item.duration === 604800 ? "周额度" : item.duration === 18000 ? "短周期" : "额度");
		}
	});

	test("public status UI places and colors only ref at exact percentage-point thresholds", async () => {
		const now = 2_000_000_000_000;
		const clock = spyOn(Date, "now").mockReturnValue(now);
		cleanup.push(async () => { clock.mockRestore(); });
		const sources: SourceStatus[] = [
			{ used: 60, ref: 44.9, tone: "dim", short: false },
			{ used: 60, ref: 45, tone: "warning", short: false },
			{ used: 60, ref: 50, tone: "error", short: true },
			{ used: null, ref: 50, tone: "dim", short: false },
		].map((item, index) => ({ id: String(index), name: item.tone, kind: "official", enabled: true, health: "healthy",
			quota: { windows: [{ name: "primary", used_percent: item.used, window_seconds: 604800,
				reset_at: now / 1_000 + Math.round(604800 * item.ref / 100), ref_cost: 1 },
				...(item.short ? [{ name: "secondary", used_percent: 20, window_seconds: 18000 }] : [])] } }));
		const server = Bun.serve({ hostname: "127.0.0.1", port: 0, fetch: () => Response.json({ running: true, inflight: 0, sources }) });
		cleanup.push(async () => { await server.stop(true); });
		let handler: Parameters<ExtensionAPI["registerCommand"]>[1]["handler"] | undefined;
		registerCodexpressCommands({ registerCommand(_name, command) { handler = command.handler; } } as ExtensionAPI, {
			resolveConnection: async () => ({ local: false, baseUrl: `http://127.0.0.1:${server.port}/omp/v1` }), refresh: async () => {},
		});
		let rendered = "";
		await handler!("status", {
			hasUI: true, modelRegistry: { getApiKeyForProvider: async () => "fixture-only-key" },
			ui: { notify(message: string) { throw new Error(message); },
				async custom(factory: Parameters<ExtensionCommandContext["ui"]["custom"]>[0]) {
					const component = await factory({ terminal: { rows: 100 }, requestRender() {} } as Parameters<typeof factory>[0],
						{ fg: (tone: string, text: string) => `<${tone}>${text}</${tone}>` } as Parameters<typeof factory>[1],
						{} as Parameters<typeof factory>[2], () => {});
					try { rendered = component.render(120).join("\n"); }
					finally { component.dispose?.(); }
				},
			},
		} as unknown as ExtensionCommandContext);
		expect(rendered).toContain("周额度 剩余 40% · <dim>ref 44.9%</dim>");
		expect(rendered).toContain("周额度 剩余 40% · <warning>ref 45.0%</warning>");
		expect(rendered).toMatch(/周额度 剩余 40%\s*\n\s+<error>ref 50\.0%<\/error>/);
		expect(rendered).toContain("周额度 额度未知 · <dim>ref 50.0%</dim>");
		expect(rendered).not.toContain("<warning>周额度");
		expect(rendered).not.toContain("<error>周额度");
	});

	test.skipIf(process.platform !== "darwin")("Mac inference handoff fails closed; only explicit independent bindings bypass it", async () => {
		const dir = await fixture();
		const path = join(dir, "gateway-integrations.json");
		const profile = join(dir, "profile");
		const { resolveConnection } = createConnectionResolver(profile);
		const device = `cxr-${"a".repeat(64)}`;
		const valid = { version: 1, mode: "remote", endpoint: "https://a.example.test", instance_id: "instance-a", device_key: device };
		const getKey = async () => { throw new Error("host secret was requested"); };
		process.env.CODEXPRESS_BASE_URL = "http://localhost:17865/v1";
		process.env.CODEXPRESS_API_KEY = "old-chat-key";
		await writeFile(path, JSON.stringify(valid), { mode: 0o600 });
		expect(await resolveConnection({ getKey })).toMatchObject({ key: device, baseUrl: "https://a.example.test/v1", selection: "remote" });
		for (const document of ["{", JSON.stringify({ version: 1, mode: "unavailable" }), ...[
			{ version: 2 }, { endpoint: "http://a.example.test" }, { endpoint: "https://u@a.example.test" },
			{ endpoint: "https://a.example.test/v1" }, { endpoint: "https://a.example.test/?x" },
			{ instance_id: "" }, { device_key: undefined }, { device_key: "old-chat-key" }, { admin_key: "wrong-lane" },
		].map(change => JSON.stringify({ ...valid, ...change }))]) {
			await writeFile(path, document);
			await expect(resolveConnection({ getKey })).rejects.toThrow(/网关|设备/);
		}
		await writeFile(path, JSON.stringify(valid));
		await chmod(path, 0o644);
		await expect(resolveConnection({ getKey })).rejects.toThrow("权限");
		await chmod(path, 0o600);
		await chmod(dir, 0o755);
		await expect(resolveConnection({ getKey })).rejects.toThrow("权限");
		await chmod(dir, 0o700);
		await rm(path);
		await symlink("missing-target", path);
		await expect(resolveConnection({ getKey })).rejects.toThrow("权限");
		await mkdir(profile);
		await writeFile(join(profile, "codexpress.json"), JSON.stringify({ baseUrl: "http://ssh.example.test:17865/omp/v1" }));
		expect(await resolveConnection({ key: "ssh-key" })).toEqual({ local: false, baseUrl: "http://ssh.example.test:17865/omp/v1", key: "ssh-key" });
	});

	test("loopback /v1 export prefers local control socket while remote /v1 and CODEXPRESS_OMP_BASE_URL normalize to /omp/v1", async () => {
		const directory = await fixture();
		const profile = join(directory, "profile");
		await mkdir(profile, { recursive: true });
		process.env.CODEXPRESS_BASE_URL = "http://127.0.0.1:17865/v1";
		process.env.CODEXPRESS_API_KEY = "chatbot-exported-key";

		const server = createServer(socket => {
			socket.setEncoding("utf8");
			let buffer = "";
			socket.on("data", chunk => {
				buffer += chunk;
				if (!buffer.includes("\n")) return;
				const request = JSON.parse(buffer);
				const data = {
					provider: "codexpress",
					api: "openai-codex-responses",
					base_url: "http://127.0.0.1:17865/omp/v1",
					key: "local-socket-key",
					enabled: true,
					running: true,
					models: [{ id: "gpt-5.4" }],
					capabilities: { websocket: false, remote_compaction_v2: null, legacy_budget_migration: true },
				};
				socket.end(`${JSON.stringify({ id: request.id, ok: true, data })}\n`);
			});
		});
		await listen(server, join(directory, "control.sock"));

		const resolver = createConnectionResolver(profile);
		const localResolved = await resolver.resolveConnection();
		expect(localResolved).toMatchObject({
			local: true,
			baseUrl: "http://127.0.0.1:17865/omp/v1",
			key: "local-socket-key",
			stateDir: directory,
			legacyBudgetMigration: true,
		});

		const configExists = await readFile(join(profile, "codexpress.json"), "utf8").then(() => true, () => false);
		expect(configExists).toBe(false);

		// Missing local control socket with loopback /v1 falls back to /omp/v1 without writing codexpress.json.
		await rm(join(directory, "control.sock"), { force: true });
		resolver.invalidate();
		const fallback = await resolver.resolveConnection();
		expect(fallback).toEqual({
			local: false,
			baseUrl: "http://127.0.0.1:17865/omp/v1",
			key: "chatbot-exported-key",
		});

		// Explicit remote /v1 normalizes to /omp/v1, and CODEXPRESS_OMP_BASE_URL wins over CODEXPRESS_BASE_URL.
		process.env.CODEXPRESS_BASE_URL = "http://192.0.2.10:17865/v1";
		const remote = await createConnectionResolver(profile).resolveConnection();
		expect(remote).toEqual({
			local: false,
			baseUrl: "http://192.0.2.10:17865/omp/v1",
			key: "chatbot-exported-key",
		});

		process.env.CODEXPRESS_OMP_BASE_URL = "http://192.0.2.20:18000/omp/v1/";
		const override = await createConnectionResolver(profile).resolveConnection();
		expect(override).toEqual({
			local: false,
			baseUrl: "http://192.0.2.20:18000/omp/v1",
			key: "chatbot-exported-key",
		});
	});

	test("createProviderModels resolves Google and OpenAI metadata and honours remote_compaction flag", () => {
		const gatewayModels = parseGatewayModels([
			{ id: "gemini-2.5-pro", remote_compaction: false },
			{ id: "gemini-3-flash-preview", remote_compaction: false },
			{ id: "gpt-5.4" },
			{ id: "o3", remote_compaction: true },
		]);
		const providerModels = createProviderModels(gatewayModels, {
			local: false,
			baseUrl: "http://127.0.0.1:17865/omp/v1",
		});
		const byId = Object.fromEntries(providerModels.map(model => [model.id, model]));

		expect(byId["gemini-2.5-pro"]).toMatchObject({
			reasoning: true,
			input: ["text", "image"],
			remoteCompaction: { enabled: false, v2StreamingEnabled: false },
		});
		expect(byId["gemini-2.5-pro"]!.contextWindow).toBeGreaterThanOrEqual(1_000_000);
		expect(byId["gemini-3-flash-preview"]).toMatchObject({
			reasoning: true,
			thinking: { mode: "google-level" },
			remoteCompaction: { enabled: false, v2StreamingEnabled: false },
		});
		expect(byId["gpt-5.4"]!.remoteCompaction).toMatchObject({
			enabled: true,
			v2StreamingEnabled: true,
		});
		expect(byId["o3"]).toMatchObject({
			reasoning: true,
			remoteCompaction: { enabled: true, v2StreamingEnabled: true },
		});
	});

	test("public status UI renders source kind labels for Google AI Studio and OpenAI API Platform", async () => {
		const sources: SourceStatus[] = [
			{ id: "g1", name: "Gemini", kind: "google", enabled: true, health: "ready" },
			{ id: "o1", name: "OpenAI Official", kind: "openai", enabled: true, health: "ready" },
			{ id: "a1", name: "Relay", kind: "api", enabled: true, health: "ready" },
		];
		const server = Bun.serve({ hostname: "127.0.0.1", port: 0, fetch: () => Response.json({ running: true, inflight: 0, sources }) });
		cleanup.push(async () => { await server.stop(true); });
		let handler: Parameters<ExtensionAPI["registerCommand"]>[1]["handler"] | undefined;
		registerCodexpressCommands({ registerCommand(_name, command) { handler = command.handler; } } as ExtensionAPI, {
			resolveConnection: async () => ({ local: false, baseUrl: `http://127.0.0.1:${server.port}/omp/v1` }), refresh: async () => {},
		});
		const notifications: string[] = [];
		await handler!("status", {
			hasUI: false,
			modelRegistry: { getApiKeyForProvider: async () => "fixture-only-key" },
			ui: { notify(message: string) { notifications.push(message); } },
		} as unknown as ExtensionCommandContext);
		const output = notifications.join("\n");
		expect(output).toContain("Google AI Studio；ready");
		expect(output).toContain("OpenAI API Platform；ready");
		expect(output).toContain("Responses API；ready");
	});

});
