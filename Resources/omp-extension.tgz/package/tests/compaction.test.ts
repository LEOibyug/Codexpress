import { afterEach, expect, test } from "bun:test";
import { mkdir, mkdtemp, readFile, rm, stat, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { createServer } from "node:net";
import { Agent } from "@oh-my-pi/pi-agent-core";
import { AuthStorage } from "@oh-my-pi/pi-ai";
import { ModelRegistry } from "@oh-my-pi/pi-coding-agent/config/model-registry";
import { Settings, findScopedSettings, withActiveSettings } from "@oh-my-pi/pi-coding-agent/config/settings";
import { AgentSession } from "@oh-my-pi/pi-coding-agent/session/agent-session";
import { SessionManager } from "@oh-my-pi/pi-coding-agent/session/session-manager";
import { describeModelCompactionPoint } from "@oh-my-pi/pi-coding-agent/session/model-compaction-threshold";
import { ExtensionRuntime, loadExtensionFromFactory } from "@oh-my-pi/pi-coding-agent/extensibility/extensions/loader";
import { ExtensionRunner } from "@oh-my-pi/pi-coding-agent/extensibility/extensions/runner";
import { EventBus } from "@oh-my-pi/pi-coding-agent/utils/event-bus";
import { getActiveProfile, getAgentDir, setAgentDir, setProfile } from "@oh-my-pi/pi-utils";
import {
	cfgCompactionEnabled, cfgCompactionMethodOrder, cfgCompactionModelThresholds,
	cfgCompactionThresholdPercent, cfgCompactionThresholdTokens,
	cfgExtendedContext,
} from "@oh-my-pi/pi-coding-agent/session/context-settings";
import { createProviderModels, parseGatewayModels } from "../src/models.js";
import { refreshActiveModelBudget, syncGatewayCompaction } from "../src/compaction.js";
import type { GatewayModel } from "../src/types.js";

const cleanup: Array<() => Promise<void>> = [];
afterEach(async () => { for (const dispose of cleanup.splice(0).reverse()) await dispose(); });
const connection = { local: false, baseUrl: "http://127.0.0.1:1/omp/v1" };
const gatewayFixture = [
	{ id: "gpt-6.1-sol", kind: "text", context_window: 1_000_000, max_context_window: 872_000, auto_compact_token_limit: 600_000 },
	{ id: "gpt-6.1-terra", kind: "text", context_window: 1_000_000, max_context_window: 1_000_000, auto_compact_token_limit: 600_000 },
	{ id: "gpt-6-astra", kind: "text", context_window: 1_000_000, max_context_window: 1_000_000, auto_compact_token_limit: 250_000 },
	{ id: "unmanaged", kind: "text", context_window: 500_000, max_context_window: 872_000, auto_compact_token_limit: null },
];
async function fixture(config = "", projectConfig = "", modelsConfig = "") {
	await mkdir(join(import.meta.dir, "../.runtime/tmp"), { recursive: true });
	const directory = await mkdtemp(join(import.meta.dir, "../.runtime/tmp/budgets-"));
	cleanup.push(() => rm(directory, { recursive: true, force: true }));
	const profile = join(directory, "profile");
	await mkdir(profile);
	if (config) await writeFile(join(profile, "config.yml"), config);
	if (modelsConfig) await writeFile(join(profile, "models.yml"), modelsConfig);
	if (projectConfig) {
		await mkdir(join(directory, ".omp"));
		await writeFile(join(directory, ".omp/config.yml"), projectConfig);
	}
	const scope = await Settings.loadIsolated({ agentDir: profile, cwd: directory, configFiles: [] });
	cleanup.push(async () => { scope.cancelPendingSaves(); });
	const auth = await AuthStorage.create(join(profile, "auth.db"));
	cleanup.push(async () => { auth.close(); });
	const registry = new ModelRegistry(auth, join(profile, "models.yml"), { settings: scope, cacheDbPath: join(profile, "models.db") });
	const register = (models: GatewayModel[]) => registry.registerProvider("codexpress", {
		api: "openai-codex-responses", apiKey: "fixture-only-key", baseUrl: connection.baseUrl, models: createProviderModels(models, connection),
	});
	return { directory, profile, scope, registry, register };
}

async function liveFixture(options: {
	local?: boolean; legacyBudgetMigration?: boolean; start?: boolean; subagent?: boolean;
	scope?: "derived" | "other-profile";
	config?: string; modelsConfig?: string; model?: GatewayModel;
} = {}) {
	const base = await fixture(options.config ?? "compaction:\n  thresholdTokens: -1\n  thresholdPercent: -1\n", "", options.modelsConfig);
	let scope = base.scope;
	if (options.scope === "derived") scope = scope.overlay({}, { derived: true });
	if (options.scope === "other-profile") {
		const agentDir = join(base.directory, "other-profile");
		await mkdir(agentDir);
		scope = await Settings.loadIsolated({ agentDir, cwd: base.directory, configFiles: [] });
		cleanup.push(async () => { scope.cancelPendingSaves(); });
	}
	const originalAgentDir = getAgentDir();
	const originalProfile = getActiveProfile();
	const environment = Object.fromEntries(["CODEXPRESS_BASE_URL", "CODEXPRESS_API_KEY", "CODEXPRESS_STATE_DIR", "PI_CODING_AGENT_DIR", "OMP_PROFILE", "PI_PROFILE"]
		.map(name => [name, process.env[name]]));
	cleanup.push(async () => {
		setAgentDir(originalAgentDir);
		if (originalProfile) setProfile(originalProfile);
		for (const [name, value] of Object.entries(environment)) {
			if (value === undefined) delete process.env[name];
			else process.env[name] = value;
		}
	});
	setAgentDir(base.profile);
	const gateway = {
		revision: "initial-budget", offline: false,
		model: options.model ?? { id: "gpt-6.1-sol", kind: "chat", context_window: 1_000_000,
			max_context_window: 1_000_000, auto_compact_token_limit: 600_000 } as GatewayModel,
		counts: { revision: 0, models: 0, migration: 0, other: 0 },
		migration: { fail: false, migrated: true, modelsChanged: true, profiles: [] as unknown[],
			block: undefined as { received: PromiseWithResolvers<void>; release: PromiseWithResolvers<void>;
				disconnected: PromiseWithResolvers<void> } | undefined },
		block: undefined as { received: PromiseWithResolvers<void>; release: PromiseWithResolvers<void> } | undefined,
	};
	const server = Bun.serve({ hostname: "127.0.0.1", port: 0, async fetch(request) {
		if (options.local) { gateway.counts.other++; return new Response(null, { status: 500 }); }
		if (request.headers.get("authorization") !== "Bearer fixture-only-key") return new Response(null, { status: 401 });
		const path = new URL(request.url).pathname;
		if (path === "/omp/v1/budgets/revision") {
			gateway.counts.revision++;
			return gateway.offline ? new Response(null, { status: 503 }) : Response.json({ revision: gateway.revision });
		}
		if (path === "/omp/v1/models") {
			gateway.counts.models++;
			const snapshot = { ...gateway.model };
			if (gateway.block) {
				gateway.block.received.resolve();
				await gateway.block.release.promise;
			}
			return Response.json({ data: [snapshot] });
		}
		gateway.counts.other++;
		return new Response("No generation, usage or management requests are allowed", { status: 500 });
	} });
	cleanup.push(async () => { gateway.block?.release.resolve(); await server.stop(true); });
	if (options.local) {
		delete process.env.CODEXPRESS_BASE_URL;
		delete process.env.CODEXPRESS_API_KEY;
		process.env.CODEXPRESS_STATE_DIR = base.directory;
		const local = createServer(socket => {
			socket.setEncoding("utf8");
			socket.on("error", (error: NodeJS.ErrnoException) => {
				if (error.code !== "EPIPE" && error.code !== "ECONNRESET") throw error;
			});
			let buffer = "";
			socket.on("data", async chunk => {
				buffer += chunk;
				if (!buffer.includes("\n")) return;
				const request = JSON.parse(buffer);
				let data: unknown;
				let ok = true;
				if (request.op === "omp.binding" || request.op === "omp.bind") {
					gateway.counts.models++;
					data = { provider: "codexpress", api: "openai-codex-responses", key: "fixture-only-key",
						base_url: `http://127.0.0.1:${server.port}/omp/v1`, enabled: true, running: true,
						models: [gateway.model], capabilities: { legacy_budget_migration: options.legacyBudgetMigration ?? true } };
				} else if (request.op === "omp.budgets.revision") {
					gateway.counts.revision++;
					data = { revision: gateway.revision };
					ok = !gateway.offline;
				} else if (request.op === "omp.budgets.migrate") {
					gateway.counts.migration++;
					gateway.migration.profiles.push(request.payload.agent_dir);
					const block = gateway.migration.block;
					if (block) {
						socket.once("close", () => block.disconnected.resolve());
						block.received.resolve();
						await block.release.promise;
					}
					ok = !gateway.migration.fail;
					data = { migrated: gateway.migration.migrated, models_changed: gateway.migration.modelsChanged };
				} else {
					gateway.counts.other++;
					ok = false;
				}
				if (socket.destroyed || socket.writableEnded) return;
				socket.end(`${JSON.stringify({ id: request.id, ok, data, error: "fixture unavailable" })}\n`);
			});
		});
		const ready = Promise.withResolvers<void>();
		local.once("error", ready.reject);
		local.listen(join(base.directory, "control.sock"), ready.resolve);
		await ready.promise;
		cleanup.push(async () => {
			gateway.migration.block?.release.resolve();
			const closed = Promise.withResolvers<void>();
			local.close(error => error ? closed.reject(error) : closed.resolve());
			await closed.promise;
		});
	} else {
		process.env.CODEXPRESS_BASE_URL = `http://127.0.0.1:${server.port}/omp/v1`;
		process.env.CODEXPRESS_API_KEY = "fixture-only-key";
	}
	const runtime = new ExtensionRuntime();
	// Before rebuilding, CODEXPRESS_EXTENSION_UNDER_TEST=../dist/index.mjs exercises the shipped 0.1.7 baseline.
	const { default: factory } = await import(process.env.CODEXPRESS_EXTENSION_UNDER_TEST ?? "../src/index.ts");
	const extension = await loadExtensionFromFactory(factory, base.directory, new EventBus(), runtime, "codexpress-live-budgets");
	for (const { name, config, sourceId } of runtime.pendingProviderRegistrations.splice(0)) base.registry.registerProvider(name, config, sourceId);
	const agent = new Agent({ initialState: { model: { ...base.registry.find("codexpress", gateway.model.id)! } } });
	const manager = SessionManager.inMemory(base.directory);
	const runner = new ExtensionRunner([extension], runtime, base.directory, manager, base.registry, undefined, scope,
		undefined, undefined, options.subagent ? { kind: "sub", id: "fixture-child", name: "sub", depth: 0 } : undefined);
	const session = new AgentSession({ agent, sessionManager: manager, settings: scope,
		modelRegistry: base.registry, extensionRunner: runner, memoryEnabled: false });
	cleanup.push(async () => { await session.dispose(); });
	const unexpectedAction = () => { throw new Error("Budget synchronization must not start, abort, compact or select a turn"); };
	runner.initialize(runtime, {
		getModel: () => session.model, isIdle: () => !session.isStreaming,
		abort: unexpectedAction, shutdown: unexpectedAction, compact: async () => unexpectedAction(),
		hasPendingMessages: () => false, getContextUsage: () => undefined, getSystemPrompt: () => session.systemPrompt,
	});
	if (options.start !== false) await runner.emit({ type: "session_start" });
	return { ...base, scope, gateway, agent, manager, runner, session };
}

test("local legacy budget handoff reaches the live SDK after factory startup at the same revision without resetting its native session", async () => {
	const legacyConfig = "compaction:\n  thresholdTokens: -1\n  thresholdPercent: -1\n  modelThresholds:\n    codexpress/gpt-6.1-sol: f600000\n    codexpress/*: 80%\n    codexpress/old-numeric: 600000\n    codexpress/old-null: null\n    codexpress/manual-model: f321000\n    other/provider-model: f123456\n";
	const retainedModels = "providers:\n  codexpress:\n    modelOverrides:\n      gpt-6.1-sol:\n        maxTokens: 12345\n      manual-model:\n        contextWindow: 320000\n";
	const { profile, scope, registry, gateway, agent, manager, runner, session } = await liveFixture({
		local: true, start: false, config: legacyConfig,
		modelsConfig: retainedModels.replace("        maxTokens: 12345", "        contextWindow: 600000\n        maxContextWindow: 600000\n        maxTokens: 12345"),
		model: { id: "gpt-6.1-sol", kind: "chat", context_window: 1_000_000,
			max_context_window: 1_000_000, auto_compact_token_limit: 400_000 },
	});
	expect(gateway.counts.migration).toBe(0); // Factory discovery has no root settings context yet.
	expect(session.model?.contextWindow).toBe(600_000);
	const message = { role: "user" as const, content: "Keep this native conversation", timestamp: Date.now() };
	agent.appendMessage(message);
	manager.appendMessage(message);
	const history = agent.state.messages;
	const entries = manager.getEntries();
	const active = session.model;
	let closed = 0;
	const nativeThread = { thread: "pre-migration-native-thread", close() { closed++; } };
	session.providerSessionState.set("openai-codex-responses", nativeThread);
	// Input fixture from the producer's completed handoff, not a fake implementation of its ownership decisions.
	// Snapshot matching and lossless leaf deletion belong to the Rust producer boundary.
	await writeFile(join(profile, "models.yml"), retainedModels);
	await writeFile(join(profile, "codexpress-compaction.json"), JSON.stringify({
		"codexpress/gpt-6.1-sol": "f600000", "codexpress/*": "80%",
		"codexpress/old-numeric": 600_000, "codexpress/old-null": null,
	}));
	const catalogs = gateway.counts.models;
	await runner.emit({ type: "session_start" });
	expect(gateway.migration.profiles).toEqual([profile]);
	expect(gateway.counts.models).toBe(catalogs);
	expect(session.model?.contextWindow).toBe(1_000_000);
	expect(describeModelCompactionPoint(scope, session.model!).tokens).toBe(400_000);
	expect(cfgCompactionModelThresholds.get(scope)).toEqual({
		"codexpress/gpt-6.1-sol": "f400000", "codexpress/manual-model": "f321000", "other/provider-model": "f123456",
	});
	expect(JSON.parse(await readFile(join(profile, "codexpress-compaction.json"), "utf8"))).toEqual({ "codexpress/gpt-6.1-sol": "f400000" });

	gateway.model = { ...gateway.model, context_window: 800_000, max_context_window: 800_000, auto_compact_token_limit: 500_000 };
	gateway.revision = "post-handoff-budget";
	await runner.emitInput("budget preflight, never submitted", undefined, "rpc");
	expect(registry.find("codexpress", gateway.model.id)?.contextWindow).toBe(800_000);
	expect(session.model?.contextWindow).toBe(800_000);
	expect(session.model?.maxTokens).toBe(12_345);
	expect(describeModelCompactionPoint(scope, session.model!).tokens).toBe(500_000);
	// Re-entering the old value is a new manual override, not a second migration opportunity.
	cfgCompactionModelThresholds.setEntry(scope, "codexpress/gpt-6.1-sol", "f600000");
	await runner.getCommand("codexpress")!.handler("connect", runner.createCommandContext());
	await runner.emitInput("same revision preflight", undefined, "rpc");
	expect(describeModelCompactionPoint(scope, session.model!).tokens).toBe(600_000);
	expect(gateway.counts.migration).toBe(1);
	expect(await readFile(join(profile, "models.yml"), "utf8")).toBe(retainedModels);
	expect(session.model).toBe(active);
	expect(agent.state.messages).toBe(history);
	expect(agent.state.messages).toEqual([message]);
	expect(manager.getEntries()).toEqual(entries);
	expect(session.providerSessionState.get("openai-codex-responses")).toBe(nativeThread);
	expect(closed).toBe(0);
	expect(gateway.counts.other).toBe(0);
});

test("local legacy migration is single-flight and retries failures and an aborted commit before memoizing success", async () => {
	const { profile, scope, gateway, manager, runner, session } = await liveFixture({ local: true, start: false,
		modelsConfig: "providers:\n  codexpress:\n    modelOverrides:\n      gpt-6.1-sol:\n        contextWindow: 600000\n        maxContextWindow: 600000\n" });
	gateway.migration.fail = true;
	await runner.emit({ type: "session_start" });
	expect(gateway.counts.migration).toBeGreaterThan(0);
	gateway.migration.fail = false;
	const before = gateway.counts.migration;
	const block = { received: Promise.withResolvers<void>(), release: Promise.withResolvers<void>(),
		disconnected: Promise.withResolvers<void>() };
	gateway.migration.block = block;
	const updating = runner.emitInput("first root migration retry", undefined, "rpc");
	await block.received.promise;
	const simultaneous = runner.emitInput("concurrent migration shares its flight", undefined, "rpc");
	expect(gateway.counts.migration).toBe(before + 1);
	await manager.newSession({ drop: true });
	// The producer committed, but the old context lost its response. A no-op retry must still reload the stale registry.
	await writeFile(join(profile, "models.yml"), "providers: {}\n");
	gateway.migration.modelsChanged = false;
	gateway.migration.migrated = false;
	gateway.migration.block = undefined;
	const switched = runner.emit({ type: "session_switch", reason: "new", previousSessionFile: undefined });
	// emit() starts handlers asynchronously: wait for the real abort to close the peer before permitting its reply.
	await block.disconnected.promise;
	block.release.resolve();
	await Promise.all([updating, simultaneous, switched]);
	expect(gateway.counts.migration).toBe(before + 2);
	expect(session.model?.contextWindow).toBe(1_000_000);
	await runner.emitInput("successful migration stays memoized", undefined, "rpc");
	expect(gateway.counts.migration).toBe(before + 2);
	gateway.model = { ...gateway.model, context_window: 800_000, max_context_window: 800_000, auto_compact_token_limit: 400_000 };
	gateway.revision = "budget-after-aborted-migration";
	await runner.emitInput("recovered ownership still follows later budgets", undefined, "rpc");
	expect(session.model?.contextWindow).toBe(800_000);
	expect(describeModelCompactionPoint(scope, session.model!).tokens).toBe(400_000);
	expect(gateway.counts.migration).toBe(before + 2);
	expect(gateway.counts.other).toBe(0);
});

test("legacy migration requires a capable local binding and the root profile settings, not a child session", async () => {
	for (const options of [
		{ legacyBudgetMigration: false }, { subagent: true },
		{ scope: "derived" as const }, { scope: "other-profile" as const },
	]) {
		const { gateway, runner } = await liveFixture({ local: true, ...options });
		await runner.emitInput("scope check only", undefined, "rpc");
		expect(gateway.counts.migration).toBe(0);
		await runner.emit({ type: "session_shutdown" });
	}
});

test("native registry and compaction policy consume gateway budgets, update and remove owned defaults without resetting a live session", async () => {
	const { directory, profile, scope, registry, register } = await fixture();
	const preferences = { baseUrl: "http://127.0.0.1:17001/omp/v1", future: { enabled: true } };
	await writeFile(join(profile, "codexpress.json"), JSON.stringify(preferences));
	cfgCompactionThresholdPercent.set(scope, -1);
	cfgCompactionThresholdTokens.set(scope, -1);
	cfgCompactionModelThresholds.setEntry(scope, "other/provider-model", "f123456");
	cfgCompactionMethodOrder.set(scope, [...cfgCompactionMethodOrder.get(scope)].reverse());
	const methods = cfgCompactionMethodOrder.get(scope);
	const models = parseGatewayModels(gatewayFixture);
	register(models);
	const original = registry.find("codexpress", "gpt-6.1-sol")!;
	// The running session predates the gateway rule refresh.
	const agent = new Agent({ initialState: { model: { ...original, contextWindow: 500_000 } } });
	const manager = SessionManager.inMemory(directory);
	const session = new AgentSession({ agent, sessionManager: manager, settings: scope, modelRegistry: registry, memoryEnabled: false });
	cleanup.push(async () => { await session.dispose(); });
	let closed = 0;
	const nativeThread = { thread: "existing-native-thread", close() { closed++; } };
	session.providerSessionState.set("openai-codex-responses", nativeThread);
	const history = agent.state.messages;
	const entries = manager.getEntries().length;
	const active = session.model;
	refreshActiveModelBudget(session, scope);
	await syncGatewayCompaction(models, scope, profile, session);
	await registry.reapplyModelPolicies();
	for (const [id, tokens] of [["gpt-6.1-sol", 600_000], ["gpt-6.1-terra", 600_000], ["gpt-6-astra", 250_000]] as const) {
		const model = registry.find("codexpress", id)!;
		expect(model.contextWindow).toBe(1_000_000);
		expect(describeModelCompactionPoint(scope, model).tokens).toBe(tokens);
	}
	expect(registry.contextWindowTiers({ provider: "codexpress", id: "unmanaged" })).toEqual({ standard: 500_000, extended: 872_000 });
	expect(describeModelCompactionPoint(scope, registry.find("codexpress", "unmanaged")!).source).toBe("default");
	const profilePath = join(profile, "codexpress-compaction.json");
	const configPath = join(profile, "config.yml");
	const times = [(await stat(profilePath)).mtimeMs, (await stat(configPath)).mtimeMs];
	await syncGatewayCompaction(models, scope, profile, session);
	expect([(await stat(profilePath)).mtimeMs, (await stat(configPath)).mtimeMs]).toEqual(times);

	models[0]!.auto_compact_token_limit = 650_000;
	await syncGatewayCompaction(models, scope, profile, session);
	expect(describeModelCompactionPoint(scope, registry.find("codexpress", "gpt-6.1-sol")!).tokens).toBe(650_000);
	models[0] = { id: "gpt-6.1-sol", kind: "chat", context_window: 500_000, max_context_window: 872_000, auto_compact_token_limit: null };
	models.splice(1, 1); // Model removal must clear its owned policy too.
	register(models);
	refreshActiveModelBudget(session, scope);
	await syncGatewayCompaction(models, scope, profile, session);
	await registry.reapplyModelPolicies();
	expect(session.model?.contextWindow).toBe(500_000);
	expect(describeModelCompactionPoint(scope, registry.find("codexpress", "gpt-6.1-sol")!).source).toBe("default");
	expect(cfgCompactionModelThresholds.get(scope)["codexpress/gpt-6.1-terra"]).toBeUndefined();
	expect(cfgCompactionModelThresholds.get(scope)["other/provider-model"]).toBe("f123456");
	expect(cfgCompactionMethodOrder.get(scope)).toEqual(methods);
	await writeFile(join(profile, "models.yml"), "providers:\n  codexpress:\n    modelOverrides:\n      gpt-6.1-sol:\n        contextWindow: 400000\n");
	await registry.refresh("offline");
	refreshActiveModelBudget(session, scope);
	expect(session.model?.contextWindow).toBe(400_000);
	expect(session.model).toBe(active);
	expect(agent.state.messages).toBe(history);
	expect(manager.getEntries()).toHaveLength(entries);
	expect(session.providerSessionState.get("openai-codex-responses")).toBe(nativeThread);
	expect(closed).toBe(0);
	expect(JSON.parse(await readFile(join(profile, "codexpress.json"), "utf8"))).toEqual(preferences);
});

test("operator thresholds, disabled compaction, legacy gateways and derived settings retain their own policy", async () => {
	const { profile, scope, register, registry } = await fixture();
	const models = parseGatewayModels(gatewayFixture);
	register(models);
	await syncGatewayCompaction(models, scope, profile);
	cfgCompactionModelThresholds.setEntry(scope, "codexpress/gpt-6.1-sol", "f321000");
	cfgCompactionModelThresholds.setEntry(scope, "codexpress/gpt-6.1-terra", undefined);
	await syncGatewayCompaction(models, scope, profile);
	await syncGatewayCompaction(models, scope, profile);
	expect(cfgCompactionModelThresholds.get(scope)["codexpress/gpt-6.1-sol"]).toBe("f321000");
	expect(cfgCompactionModelThresholds.get(scope)["codexpress/gpt-6.1-terra"]).toBeUndefined();
	await syncGatewayCompaction(models.map(({ auto_compact_token_limit: _, ...model }) => model), scope, profile);
	expect(cfgCompactionModelThresholds.get(scope)["codexpress/gpt-6-astra"]).toBe("f250000");
	cfgCompactionModelThresholds.setEntry(scope, "codexpress/*", "70%");
	await syncGatewayCompaction(models, scope, profile);
	expect(describeModelCompactionPoint(scope, registry.find("codexpress", "gpt-6-astra")!).source).toBe("codexpress/*");
	cfgCompactionModelThresholds.setEntry(scope, "codexpress/*", undefined);
	await syncGatewayCompaction(models, scope, profile);
	cfgCompactionThresholdTokens.override(scope, 111_111);
	cfgCompactionThresholdPercent.override(scope, 50);
	cfgCompactionEnabled.override(scope, false);
	await syncGatewayCompaction(models, scope, profile);
	expect(cfgCompactionThresholdTokens.get(scope)).toBe(111_111);
	expect(cfgCompactionThresholdPercent.get(scope)).toBe(50);
	expect(describeModelCompactionPoint(scope, registry.find("codexpress", "gpt-6-astra")!).tokens).toBeUndefined();
	expect(cfgCompactionModelThresholds.get(scope)["codexpress/gpt-6-astra"]).toBeUndefined();

	cfgExtendedContext.override(scope, true);
	await registry.reapplyModelPolicies();
	const parentBudget = registry.find("codexpress", "unmanaged")!;
	expect(parentBudget.contextWindow).toBe(872_000);
	const before = await readFile(join(profile, "codexpress-compaction.json"), "utf8");
	const child = scope.overlay({
		"compaction.enabled": true, "compaction.modelThresholdsEnabled": false,
		"compaction.thresholdTokens": 98_765, "compaction.thresholdPercent": -1,
		"extendedContext": false,
	}, { derived: true });
	await withActiveSettings(child, async () => {
		expect(findScopedSettings()).toBe(child);
		expect(describeModelCompactionPoint(child, registry.find("codexpress", "gpt-6.1-sol")!).tokens).toBe(98_765);
		const childBudget = { ...parentBudget };
		refreshActiveModelBudget({ model: childBudget, modelRegistry: registry }, child);
		expect(childBudget.contextWindow).toBe(500_000);
		expect(parentBudget.contextWindow).toBe(872_000);
		await syncGatewayCompaction([], child, profile);
	});
	expect(await readFile(join(profile, "codexpress-compaction.json"), "utf8")).toBe(before);
	const separate = await fixture("", "compaction:\n  modelThresholds:\n    codexpress/*: 80%\n    other/provider-model: f99999\n");
	await syncGatewayCompaction(models, separate.scope, separate.profile);
	expect(cfgCompactionModelThresholds.get(separate.scope)).toEqual({ "codexpress/*": "80%", "other/provider-model": "f99999" });
	expect(separate.scope.getGlobalSettings().compaction).toBeUndefined();
	expect(cfgCompactionModelThresholds.get(scope)["codexpress/gpt-6.1-sol"]).toBe("f321000");
});

// This integration deliberately uses the platform clock to exercise the SDK's real managed timer and teardown ownership.
// Faking global timers would replace the lifecycle boundary this regression protects.
async function eventually(predicate: () => boolean, timeout = 5_500) {
	const deadline = Date.now() + timeout;
	while (!predicate()) {
		if (Date.now() >= deadline) throw new Error("Gateway budget did not reach the live SDK session within one polling interval");
		await Bun.sleep(20);
	}
}

test("extension factory synchronizes idle budgets within five seconds without rediscovery, new prompts or session resets", async () => {
	const { profile, scope, registry, gateway, agent, manager, runner, session } = await liveFixture();
	const message = { role: "user" as const, content: "Existing history must remain unchanged", timestamp: Date.now() };
	agent.appendMessage(message);
	manager.appendMessage(message);
	const history = agent.state.messages;
	const entries = manager.getEntries();
	const active = session.model;
	let closed = 0;
	const nativeThread = { thread: "existing-native-thread", close() { closed++; } };
	session.providerSessionState.set("openai-codex-responses", nativeThread);
	expect(session.model?.contextWindow).toBe(1_000_000);
	expect(describeModelCompactionPoint(scope, session.model!).tokens).toBe(600_000);

	gateway.model = { ...gateway.model, context_window: 800_000, max_context_window: 800_000, auto_compact_token_limit: 400_000 };
	gateway.revision = "edited-budget";
	// No prompt/event is dispatched here: only the extension's real managed five-second timer can update the host.
	await eventually(() => session.model?.contextWindow === 800_000
		&& describeModelCompactionPoint(scope, session.model!).tokens === 400_000);
	expect(registry.find("codexpress", gateway.model.id)?.contextWindow).toBe(800_000);
	const catalogRequests = gateway.counts.models;
	// The live model changes before flush()/ownership rename finishes. Join that real request, not a guessed delay.
	await runner.emitInput("acknowledge the timer's completed budget commit", undefined, "rpc");
	expect(gateway.counts.models).toBe(catalogRequests);
	const probes = gateway.counts.revision;
	const paths = [join(profile, "config.yml"), join(profile, "codexpress-compaction.json")];
	const modified = await Promise.all(paths.map(async path => (await stat(path)).mtimeMs));
	await eventually(() => gateway.counts.revision > probes);
	await runner.emitInput("acknowledge the unchanged timer probe", undefined, "rpc");
	expect(gateway.counts.models).toBe(catalogRequests);
	expect(await Promise.all(paths.map(async path => (await stat(path)).mtimeMs))).toEqual(modified);

	// Explicit reconnects also acknowledge the version; the next preflight must not rediscover it.
	await runner.getCommand("codexpress")!.handler("connect", runner.createCommandContext());
	const reconnectedCatalogRequests = gateway.counts.models;
	await runner.emitBeforeAgentStart("preflight only, never sent to a model", undefined, []);
	expect(gateway.counts.models).toBe(reconnectedCatalogRequests);

	gateway.model = { ...gateway.model, context_window: 500_000, max_context_window: 872_000, auto_compact_token_limit: null };
	gateway.revision = "removed-budget";
	// Input precedes even the failed-assistant recovery check; before_agent_start is the SDK fallback.
	await runner.emitInput("input preflight only", undefined, "rpc");
	expect(session.model?.contextWindow).toBe(500_000);
	expect(describeModelCompactionPoint(scope, session.model!).source).toBe("default");
	expect(cfgCompactionModelThresholds.get(scope)["codexpress/gpt-6.1-sol"]).toBeUndefined();
	gateway.offline = true;
	const offlineCatalogRequests = gateway.counts.models;
	await runner.emitBeforeAgentStart("offline preflight only", undefined, []);
	expect(gateway.counts.models).toBe(offlineCatalogRequests);
	expect(session.model?.contextWindow).toBe(500_000);

	gateway.offline = false;
	gateway.model = { ...gateway.model, context_window: 900_000, max_context_window: 900_000, auto_compact_token_limit: 700_000 };
	gateway.revision = "pending-at-shutdown";
	const block = { received: Promise.withResolvers<void>(), release: Promise.withResolvers<void>() };
	gateway.block = block;
	const updating = runner.emitInput("pending preflight only", undefined, "rpc");
	await eventually(() => gateway.counts.models > offlineCatalogRequests);
	await block.received.promise;
	const simultaneousCheck = runner.emitInput("another preflight shares the request", undefined, "rpc");
	const shutdownCatalogRequests = gateway.counts.models;
	await runner.emit({ type: "session_shutdown" });
	block.release.resolve();
	await Promise.all([updating, simultaneousCheck]);
	const shutdownProbes = gateway.counts.revision;
	await Bun.sleep(5_100);
	expect(gateway.counts.revision).toBe(shutdownProbes);
	expect(gateway.counts.models).toBe(shutdownCatalogRequests);
	expect(session.model?.contextWindow).toBe(500_000);
	expect(cfgCompactionModelThresholds.get(scope)["codexpress/gpt-6.1-sol"]).toBeUndefined();
	expect(session.model).toBe(active);
	expect(agent.state.messages).toBe(history);
	expect(agent.state.messages).toEqual([message]);
	expect(manager.getEntries()).toEqual(entries);
	expect(session.providerSessionState.get("openai-codex-responses")).toBe(nativeThread);
	expect(closed).toBe(0);
	expect(gateway.counts.other).toBe(0);
}, 35_000);

test("session switch cancels a pending old budget snapshot and commits the current session revision", async () => {
	const { scope, gateway, manager, runner, session } = await liveFixture();
	gateway.model = { ...gateway.model, context_window: 800_000, max_context_window: 800_000, auto_compact_token_limit: 400_000 };
	gateway.revision = "old-session-pending";
	const block = { received: Promise.withResolvers<void>(), release: Promise.withResolvers<void>() };
	gateway.block = block;
	const before = gateway.counts.models;
	const oldCheck = runner.emitInput("old session preflight only", undefined, "rpc");
	await eventually(() => gateway.counts.models > before);
	await block.received.promise;
	await manager.newSession({ drop: true });
	gateway.model = { ...gateway.model, context_window: 700_000, max_context_window: 700_000, auto_compact_token_limit: 300_000 };
	gateway.revision = "new-session-budget";
	gateway.block = undefined;
	const switched = runner.emit({ type: "session_switch", reason: "new", previousSessionFile: undefined });
	block.release.resolve();
	await Promise.all([oldCheck, switched]);
	expect(session.model?.contextWindow).toBe(700_000);
	expect(describeModelCompactionPoint(scope, session.model!).tokens).toBe(300_000);
	const currentCatalogRequests = gateway.counts.models;
	await runner.emitBeforeAgentStart("new session preflight only", undefined, []);
	expect(gateway.counts.models).toBe(currentCatalogRequests);
	expect(gateway.counts.other).toBe(0);
});
