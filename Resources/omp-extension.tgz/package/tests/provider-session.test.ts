import { expect, test } from "bun:test";
import { mkdir, mkdtemp, rm } from "node:fs/promises";
import { join } from "node:path";
import { Type } from "@oh-my-pi/omptype/typebox";
import { getBundledModel } from "@oh-my-pi/pi-catalog/models";
import { streamSimple } from "@oh-my-pi/pi-ai";
import type { ExtensionContext } from "@oh-my-pi/pi-coding-agent";
import { ExtensionRuntime, loadExtensionFromFactory } from "@oh-my-pi/pi-coding-agent/extensibility/extensions/loader";
import { EventBus } from "@oh-my-pi/pi-coding-agent/utils/event-bus";
import { getActiveProfile, getAgentDir, setAgentDir, setProfile } from "@oh-my-pi/pi-utils";
import codexpressExtension from "../src/index.js";

test("workspace cache affinity is opaque and independent of native SDK bodies and threads", async () => {
	await mkdir(join(import.meta.dir, "../.runtime/tmp"), { recursive: true });
	const directory = await mkdtemp(join(import.meta.dir, "../.runtime/tmp/provider-session-"));
	const names = ["CODEXPRESS_BASE_URL", "CODEXPRESS_API_KEY", "PI_CODING_AGENT_DIR", "OMP_PROFILE", "PI_PROFILE"] as const;
	const saved = Object.fromEntries(names.map(name => [name, process.env[name]]));
	const originalAgentDir = getAgentDir();
	const originalProfile = getActiveProfile();
	type Body = { model: string; prompt_cache_key?: string; client_metadata: Record<string, unknown>; [key: string]: unknown };
	const observed: Array<{ body: Body; headers: Headers }> = [];
	const server = Bun.serve({
		hostname: "127.0.0.1", port: 0,
		async fetch(request) {
			if (request.method === "GET") return Response.json({ data: [{ id: "gpt-6.1-sol" }] });
			const body = await request.json() as Body;
			observed.push({ body, headers: request.headers });
			const response = { id: `fixture-${observed.length}`, model: body.model, status: "completed", output: [], usage: { input_tokens: 8, output_tokens: 0 } };
			return new Response(`event: response.completed\ndata: ${JSON.stringify({ type: "response.completed", response })}\n\n`, { headers: { "content-type": "text/event-stream" } });
		},
	});
	try {
		const baseUrl = `http://127.0.0.1:${server.port}/omp/v1`;
		process.env.CODEXPRESS_BASE_URL = baseUrl;
		process.env.CODEXPRESS_API_KEY = "fixture-only-key";
		const loadHook = async (profile: string) => {
			setAgentDir(join(directory, profile));
			const extension = await loadExtensionFromFactory(codexpressExtension, directory, new EventBus(), new ExtensionRuntime());
			const hook = extension.handlers.get("before_provider_request")?.[0];
			if (!hook) throw new Error("Missing provider request handler");
			return hook;
		};
		const hooks = { primary: await loadHook("primary"), other: await loadHook("other") };
		const reference = getBundledModel("openai-codex", "gpt-6.1-sol");
		if (!reference) throw new Error("Missing fixture model in the host catalog");
		const model = { ...reference, provider: "codexpress", api: "openai-codex-responses" as const, baseUrl, preferWebsockets: false };
		// Advisors can reuse the parent's hook context for another wire protocol.
		const parentContext = { model, cwd: directory, sessionManager: { getSessionId: () => "parent-fallback" } } as ExtensionContext;
		for (const metadata of [undefined, {}, { session_id: "" }, { session_id: 1 }]) {
			const payload = { input: "Other protocol fixture", prompt_cache_key: "explicit-key",
				...(metadata === undefined ? {} : { client_metadata: metadata }) };
			expect(await hooks.primary({ type: "before_provider_request", payload }, parentContext)).toEqual({
				...payload, client_metadata: { ...metadata, codexpress_session_id: "parent-fallback" },
			});
		}
		const cases = [
			{ session: "root-session", workspace: "one" },
			{ session: "new-session", workspace: "one" },
			{ session: "root-session", workspace: "two" },
			{ session: "root-session", workspace: "one", key: "explicit-shared-key" },
			{ session: "root-session:advisor:fixture", workspace: "two", key: "explicit-shared-key" },
			{ session: "root-session", workspace: "one", key: "other-explicit-key" },
			{ session: "root-session", workspace: "one", profile: "other" },
			{ session: "root-session", workspace: "one", disabled: true },
			{ session: "root-session", workspace: "one", key: "" },
		] as const;
		const before: Body[] = [];
		for (const item of cases) {
			const ctx = { cwd: join(directory, item.workspace), model, sessionManager: { getSessionId: () => "root-session" } } as ExtensionContext;
			const hook = "profile" in item ? hooks[item.profile] : hooks.primary;
			const stream = streamSimple(model, {
				messages: [{ role: "user", content: "Fixture input.", timestamp: 1 }],
				tools: [{ name: "fixture_tool", description: "Fixture tool", parameters: Type.Object({}) }],
			}, {
				apiKey: "fixture-only-key", sessionId: item.session, parentSessionId: "root-session",
				...("key" in item ? { promptCacheKey: item.key } : {}),
				...("disabled" in item ? { cacheRetention: "none" as const } : {}),
				preferWebsockets: false,
				onPayload: async payload => {
					before.push(JSON.parse(JSON.stringify(payload)) as Body);
					const body = payload as Body;
					const replacement = await hook({ type: "before_provider_request", payload: {
						...body, client_metadata: { ...body.client_metadata, codexpress_cache_group: "stale-inherited-group" },
					} }, ctx);
					expect(JSON.parse(JSON.stringify(payload))).toEqual(before[before.length - 1]);
					return replacement;
				},
			});
			expect((await stream.result()).stopReason).toBe("stop");
		}
		expect(observed).toHaveLength(cases.length);
		const groups = observed.map(value => value.body.client_metadata.codexpress_cache_group);
		for (const group of groups.slice(0, 7)) expect(group).toMatch(/^[0-9a-f]{64}$/);
		expect(groups[0]).toBe(groups[1]);
		expect(groups[0]).not.toBe(groups[2]);
		expect(groups[0]).not.toBe(groups[3]);
		expect(groups[3]).toBe(groups[4]);
		expect(groups[3]).not.toBe(groups[5]);
		expect(groups[0]).not.toBe(groups[6]);
		expect(groups.slice(7)).toEqual([null, null]);
		for (const [index, { body, headers }] of observed.entries()) {
			const { codexpress_session_id: privateSession, codexpress_cache_group: _group, ...metadata } = body.client_metadata;
			expect(privateSession).toBe(metadata.session_id);
			expect({ ...body, client_metadata: metadata }).toEqual(before[index]);
			expect(headers.get("session_id")).toBe("root-session");
			expect(headers.get("session-id")).toBe("root-session");
			expect(headers.get("conversation_id")).toBe("root-session");
			expect(headers.get("thread-id")).toBe(metadata.thread_id as string);
		}
		expect(observed[3].body.client_metadata.session_id).not.toBe(observed[4].body.client_metadata.session_id);
	} finally {
		await server.stop(true);
		await rm(directory, { recursive: true, force: true });
		setAgentDir(originalAgentDir);
		if (originalProfile) setProfile(originalProfile);
		for (const name of names) {
			if (saved[name] === undefined) delete process.env[name];
			else process.env[name] = saved[name];
		}
	}
});
