import * as path from "node:path";

const root = path.resolve(import.meta.dir, "..");
const result = await Bun.build({
	entrypoints: [path.join(root, "src/index.ts")],
	outdir: path.join(root, "dist"),
	naming: "index.mjs",
	target: "bun",
	format: "esm",
	external: ["@oh-my-pi/*"],
});
if (!result.success) {
	for (const message of result.logs) process.stderr.write(`${message}\n`);
	process.exitCode = 1;
} else {
	await Bun.write(path.join(root, "dist/sdk.lock"), Bun.file(path.join(root, "bun.lock")));
	process.stdout.write("Built dist/index.mjs\n");
}
