import { createHash } from "node:crypto";
import { resolve } from "node:path";
import type { ExtensionAPI, ExtensionContext, ProviderConfig } from "@oh-my-pi/pi-coding-agent";
import { findScopedSettings } from "@oh-my-pi/pi-coding-agent/config/settings";
import { describeModelCompactionPoint } from "@oh-my-pi/pi-coding-agent/session/model-compaction-threshold";
import { getAgentDir, isRecord } from "@oh-my-pi/pi-utils";
import { callLocalManagement, createConnectionResolver, discoverGatewayModels, fetchBudgetRevision } from "./connection.js";
import { createProviderModels } from "./models.js";
import { refreshActiveModelBudget, syncGatewayCompaction } from "./compaction.js";
import { createCodexpressUsageProvider } from "./usage.js";
import { registerCodexpressCommands } from "./commands.js";
import { registerKeyboardSelection } from "./keyboard-selection.js";
import type { Connection, CodexpressProviderModel, GatewayModel } from "./types.js";

export default async function codexpressExtension(pi: ExtensionAPI): Promise<void> {
	registerKeyboardSelection(pi);
	const profileDir = resolve(getAgentDir());
	const resolver = createConnectionResolver(profileDir);
	const { resolveConnection } = resolver;
	const usage = createCodexpressUsageProvider(resolveConnection);
	let connection: Connection | undefined;
	let models: CodexpressProviderModel[] = [];
	let activeContext: ExtensionContext | undefined;
	let contextIdentity: string | undefined;
	let controller = new AbortController();
	let stopped = false;
	let timer: Timer | undefined;
	let pending: { signal: AbortSignal; promise: Promise<void> } | undefined;
	let lastOverrideNotice: string | undefined;
	const seenRevisions = new Map<string, string>();
	const legacyMigrations = new Map<string, { complete: boolean; refreshRequired: boolean; pending?: Promise<void> }>();
	const managedBaseUrls = new Set<string>();
	const modelCache = new Map<string, CodexpressProviderModel[]>();
	const gatewayCache = new Map<string, GatewayModel[]>();
	const connectionIdentity = (value: Connection) => JSON.stringify([value.baseUrl, value.key, value.local, value.stateDir]);

	const updateCompactionEndpoints = (
		compaction: { endpoint?: string; v2Endpoint?: string } | undefined,
		previousBaseUrl: string,
		baseUrl: string,
	) => {
		if (compaction?.v2Endpoint === `${previousBaseUrl}/codex/responses`) {
			compaction.v2Endpoint = `${baseUrl}/codex/responses`;
		}
		if (compaction?.endpoint === `${previousBaseUrl}/codex/responses/compact`) {
			compaction.endpoint = `${baseUrl}/codex/responses/compact`;
		}
	};

	const updateConnection = (next: Connection) => {
		managedBaseUrls.add(next.baseUrl);
		const previousBaseUrl = connection?.baseUrl;
		connection = next;
		if (previousBaseUrl === next.baseUrl) return;
		models = models.map(model => {
			const updated = { ...model, remoteCompaction: { ...model.remoteCompaction } };
			if (previousBaseUrl) updateCompactionEndpoints(updated.remoteCompaction, previousBaseUrl, next.baseUrl);
			return updated;
		});
		register();
	};

	const oauth: NonNullable<ProviderConfig["oauth"]> = {
		name: "Codexpress",
		async login(callbacks) {
			const configured = await resolveConnection({ signal: callbacks.signal });
			const key = configured.local || configured.key ? configured.key : (await callbacks.onPrompt({
				message: "Codexpress 客户端 Key", placeholder: "在 Codexpress 的客户端接入页复制 Key", secret: true,
			})).trim();
			if (!configured.local && !key) throw new Error("未填写 Codexpress 客户端 Key，原有登录未变更。");
			const next = await resolveConnection({ activate: true, key: configured.local ? undefined : key, signal: callbacks.signal });
			if (!next.key) throw new Error("Codexpress 未返回模型 Key，原有登录未变更。");
			await refresh(next, activeContext);
			return next.key;
		},
	};

	const register = () => {
		pi.registerProvider("codexpress", {
			api: "openai-codex-responses",
			...(connection ? { baseUrl: connection.baseUrl } : {}),
			...(process.env.CODEXPRESS_API_KEY ? { apiKey: "CODEXPRESS_API_KEY" } : {}),
			authHeader: true,
			oauth,
			usage,
			models,
			async fetchDynamicModels(key) {
				const signal = controller.signal;
				let next: Connection | undefined;
				try {
					next = await resolveConnection({ key, signal });
					const gatewayModels = next.local ? (await resolver.getBinding({ signal })).models : await discoverGatewayModels(next, signal);
					signal.throwIfAborted();
					const discovered = createProviderModels(gatewayModels, next);
					gatewayCache.set(connectionIdentity(next), gatewayModels);
					modelCache.set(connectionIdentity(next), discovered);
					return discovered;
				} catch {
					if (next) return modelCache.get(connectionIdentity(next)) ?? [];
					return models;
				}
			},
		});
	};

	async function load(next: Connection, ctx: ExtensionContext | undefined, signal: AbortSignal, revision?: string): Promise<void> {
		if (!next.local && !next.key) return;
		// Read the version before discovery: a concurrent gateway edit must never mark an older catalog as current.
		revision ??= await fetchBudgetRevision(next, signal).catch(() => undefined);
		const gatewayModels = next.local ? (await resolver.getBinding({ signal })).models : await discoverGatewayModels(next, signal);
		signal.throwIfAborted();
		const discovered = createProviderModels(gatewayModels, next);
		const nextIds = new Set(discovered.map(model => model.id));
		if (models.some(model => !nextIds.has(model.id))) pi.unregisterProvider("codexpress");
		managedBaseUrls.add(next.baseUrl);
		connection = next;
		models = discovered;
		modelCache.set(connectionIdentity(next), discovered);
		gatewayCache.set(connectionIdentity(next), gatewayModels);
		register();
		await applyBudgets(ctx, signal);
		signal.throwIfAborted();
		if (revision) seenRevisions.set(connectionIdentity(next), revision);
		notifyBudgetOverride(ctx);
	}

	async function migrateLegacyBudgets(ctx: ExtensionContext | undefined, signal?: AbortSignal): Promise<boolean> {
		const next = connection;
		if (!ctx || ctx.agent.kind !== "main" || !next?.local || !next.stateDir || !next.legacyBudgetMigration) return false;
		const stateDir = next.stateDir;
		const scope = findScopedSettings(ctx.cwd, profileDir);
		if (!scope || scope.overlayLayers().derived || resolve(scope.getAgentDir()) !== profileDir) return false;
		const identity = connectionIdentity(next);
		let migration = legacyMigrations.get(identity);
		if (migration?.complete) return false;
		if (!migration) {
			migration = { complete: false, refreshRequired: false };
			legacyMigrations.set(identity, migration);
		}
		if (migration.pending) {
			await migration.pending;
			signal?.throwIfAborted();
			return true;
		}
		const state = migration;
		const promise = (async () => {
			try {
				const result = await callLocalManagement<unknown>(stateDir, "omp.budgets.migrate", { agent_dir: profileDir }, signal);
				if (!isRecord(result) || typeof result.migrated !== "boolean" || typeof result.models_changed !== "boolean") {
					throw new Error("Codexpress 返回了无效的旧预算迁移结果。");
				}
				state.refreshRequired ||= result.models_changed;
				signal?.throwIfAborted();
				if (state.refreshRequired) await ctx.modelRegistry.refresh("offline");
				signal?.throwIfAborted();
				state.refreshRequired = false;
				state.complete = true;
			} catch (error) {
				// The gateway may have committed before a lost/aborted reply; reconcile the cache on retry too.
				state.refreshRequired = true;
				throw error;
			}
		})();
		state.pending = promise;
		try { await promise; }
		finally { if (state.pending === promise) state.pending = undefined; }
		return true;
	}

	async function applyBudgets(ctx?: ExtensionContext, signal?: AbortSignal): Promise<void> {
		signal?.throwIfAborted();
		if (!ctx || !connection) return;
		const scope = findScopedSettings(ctx.cwd, profileDir);
		if (!scope) return;
		await migrateLegacyBudgets(ctx, signal);
		signal?.throwIfAborted();
		// Refit the existing public model before settings listeners observe a changed threshold.
		refreshActiveModelBudget(ctx, scope);
		const gatewayModels = gatewayCache.get(connectionIdentity(connection));
		if (gatewayModels) await syncGatewayCompaction(gatewayModels, scope, profileDir, ctx, signal);
		signal?.throwIfAborted();
		refreshActiveModelBudget(ctx, scope);
	}

	function notifyBudgetOverride(ctx?: ExtensionContext): void {
		const active = ctx?.model;
		if (!ctx || !connection || active?.provider !== "codexpress") return;
		const advertised = gatewayCache.get(connectionIdentity(connection))?.find(model => model.id === active.id);
		const scope = findScopedSettings(ctx.cwd, profileDir);
		if (!advertised || !scope) return;
		const differences: string[] = [];
		if (advertised.context_window && active.contextWindow !== advertised.context_window) {
			differences.push(`当前窗口 ${active.contextWindow}，Codexpress 设置 ${advertised.context_window}`);
		}
		if (advertised.auto_compact_token_limit) {
			const point = describeModelCompactionPoint(scope, active);
			if (point.tokens !== advertised.auto_compact_token_limit) {
				differences.push(`${point.tokens === undefined ? "当前无自动压缩点" : `当前压缩点 ${point.tokens}`}，Codexpress 设置 ${advertised.auto_compact_token_limit}`);
			}
		}
		const notice = differences.length ? `${active.id} ${differences.join("；")}；OMP 自定义设置或窗口限制优先。` : undefined;
		const identity = notice && JSON.stringify([ctx.sessionManager.getSessionId(), ctx.cwd, notice]);
		if (notice && identity !== lastOverrideNotice) ctx.ui.notify(notice, "warning");
		lastOverrideNotice = identity;
	}

	async function synchronize(ctx?: ExtensionContext, force = false, next?: Connection): Promise<void> {
		const signal = controller.signal;
		while (pending) {
			const previous = pending;
			await previous.promise.catch(error => {
				if (!force && previous.signal === signal) throw error;
			});
			signal.throwIfAborted();
			if (!force && previous.signal === signal) return;
		}
		signal.throwIfAborted();
		const promise = (async () => {
			let revision: string | undefined;
			if (!force && connection) {
				revision = await fetchBudgetRevision(connection, signal);
				if (seenRevisions.get(connectionIdentity(connection)) === revision) {
					if (await migrateLegacyBudgets(ctx, signal)) await applyBudgets(ctx, signal);
					return;
				}
			}
			resolver.invalidate();
			const key = await ctx?.modelRegistry.getApiKeyForProvider("codexpress", ctx.sessionManager.getSessionId());
			signal.throwIfAborted();
			const resolved = next ?? await resolveConnection({ key, signal });
			if (connection && connectionIdentity(connection) !== connectionIdentity(resolved)) revision = undefined;
			await load(resolved, ctx, signal, revision);
		})();
		pending = { signal, promise };
		try { await promise; }
		finally { if (pending?.promise === promise) pending = undefined; }
	}

	const useContext = (ctx: ExtensionContext) => {
		if (stopped) return;
		const identity = JSON.stringify([ctx.sessionManager.getSessionId(), ctx.cwd]);
		if (contextIdentity !== identity) {
			controller.abort();
			controller = new AbortController();
			contextIdentity = identity;
		}
		activeContext = ctx;
		if (!timer) timer = ctx.setInterval(async () => {
			if (!activeContext || !connection || (!connection.local && !connection.key)) return;
			await synchronize(activeContext).catch(() => {
				// Offline polling retains the last successful budgets and never starts a turn or re-authenticates.
			});
		}, 5_000);
	};
	const refresh = async (next?: Connection, ctx?: ExtensionContext): Promise<void> => {
		if (ctx) useContext(ctx);
		await synchronize(ctx, true, next);
	};
	const checkBudgets = async (_event: unknown, ctx: ExtensionContext) => {
		useContext(ctx);
		if (!stopped) await synchronize(ctx).catch(() => {});
	};
	const refreshLifecycle = async (_event: unknown, ctx: ExtensionContext) => {
		useContext(ctx);
		const signal = controller.signal;
		if (stopped) return;
		const refreshed = await synchronize(ctx).then(() => true, () => false);
		if (!signal.aborted) {
			try {
				await applyBudgets(ctx, signal);
				if (refreshed) notifyBudgetOverride(ctx);
			} catch {
				// Preserve the last successful budget when the session closes or persistence is unavailable.
			}
		}
	};

	// Registration precedes discovery so package validation and offline /login need no network.
	register();
	registerCodexpressCommands(pi, { resolveConnection, refresh });
	pi.on("session_start", refreshLifecycle);
	pi.on("session_switch", refreshLifecycle);
	// Failed historical turns are checked before before_agent_start; interactive/RPC input runs earlier.
	pi.on("input", checkBudgets);
	pi.on("session_shutdown", () => {
		stopped = true;
		controller.abort();
		if (timer) activeContext?.clearTimer(timer);
		timer = undefined;
		activeContext = undefined;
	});
	pi.on("before_agent_start", async (_event, ctx) => {
		useContext(ctx);
		const signal = controller.signal;
		if (stopped) return;
		const model = ctx.model;
		if (model?.provider !== "codexpress") return;
		const previousBaseUrl = model.baseUrl.replace(/\/+$/, "");
		const managed = managedBaseUrls.has(previousBaseUrl);
		let next: Connection;
		try {
			const key = await ctx.modelRegistry.getApiKeyForProvider("codexpress", ctx.sessionManager.getSessionId());
			next = await resolveConnection({ key, signal });
			signal.throwIfAborted();
		} catch (error) {
			// Host handlers report errors but do not stop a turn unless explicitly aborted.
			if (managed && !signal.aborted) ctx.abort();
			throw error;
		}
		updateConnection(next);
		if (managed) model.baseUrl = next.baseUrl;
		for (const baseUrl of managedBaseUrls) {
			updateCompactionEndpoints(model.remoteCompaction, baseUrl, next.baseUrl);
		}
		await checkBudgets(undefined, ctx);
	});
	pi.on("before_provider_request", (event, ctx) => {
		if (ctx.model?.provider !== "codexpress") return;
		if (!isRecord(event.payload)) return;
		const metadata = isRecord(event.payload.client_metadata) ? event.payload.client_metadata : {};
		const nativeSessionId = typeof metadata.session_id === "string" && metadata.session_id ? metadata.session_id : undefined;
		const sessionId = nativeSessionId ?? ctx.sessionManager.getSessionId();
		if (!nativeSessionId) {
			return { ...event.payload, client_metadata: { ...metadata, codexpress_session_id: sessionId } };
		}
		const cacheKey = event.payload.prompt_cache_key;
		// Native session keys are per conversation; only an explicit override pins a different scope.
		const cacheGroup = typeof cacheKey === "string" && cacheKey.length > 0
			? createHash("sha256").update(JSON.stringify([
				"codexpress-cache-group-v1", profileDir,
				cacheKey === sessionId ? ["workspace", resolve(ctx.cwd)] : ["key", cacheKey],
			])).digest("hex") : null;
		return { ...event.payload, client_metadata: {
			...metadata, codexpress_session_id: sessionId, codexpress_cache_group: cacheGroup,
		} };
	});
	await synchronize(undefined, true).catch(() => {
		// Offline startup keeps /login registered without inventing available models.
	});
}
