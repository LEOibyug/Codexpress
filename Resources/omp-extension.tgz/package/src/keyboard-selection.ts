import type { ExtensionAPI, ExtensionContext } from "@oh-my-pi/pi-coding-agent";
import {
	BRACKETED_PASTE_END,
	BRACKETED_PASTE_START,
	canonicalKeyId,
	CURSOR_MARKER,
	Editor,
	extractPrintableText,
	getKeybindings,
	getSegmenter,
	matchesKey,
	moveWordLeft,
	moveWordRight,
	parseKey,
	type EditorTextDecorationContext,
	type Keybinding,
	type NativeNode,
	type KeyId,
} from "@oh-my-pi/pi-tui";
import { CustomEditor } from "@oh-my-pi/pi-tui/prompt/custom-editor";
import { theme } from "@oh-my-pi/pi-tui/theme";

type Position = { line: number; col: number };
type Motion = "left" | "right" | "up" | "down" | "wordLeft" | "wordRight" | "start" | "end";
type EditorFactory = NonNullable<ReturnType<ExtensionContext["ui"]["getEditorComponent"]>>;

const selectionKeys: ReadonlyArray<readonly [Motion, readonly string[]]> = [
	["left", ["shift+left"]],
	["right", ["shift+right"]],
	["up", ["shift+up"]],
	["down", ["shift+down"]],
	["wordLeft", ["alt+shift+left", "ctrl+shift+left", "super+alt+shift+left"]],
	["wordRight", ["alt+shift+right", "ctrl+shift+right", "super+alt+shift+right"]],
	["start", ["shift+home"]],
	["end", ["shift+end"]],
];
const deleteActions: readonly Keybinding[] = [
	"tui.editor.deleteCharBackward", "tui.editor.deleteCharForward",
	"tui.editor.deleteWordBackward", "tui.editor.deleteWordForward",
	"tui.editor.deleteToLineStart", "tui.editor.deleteToLineEnd",
];
const navigationActions: readonly Keybinding[] = [
	"tui.editor.cursorUp", "tui.editor.cursorDown", "tui.editor.cursorWordLeft",
	"tui.editor.cursorWordRight", "tui.editor.cursorLineStart", "tui.editor.cursorLineEnd",
	"tui.editor.pageUp", "tui.editor.pageDown", "tui.editor.jumpForward", "tui.editor.jumpBackward",
];

function offset(lines: readonly string[], position: Position): number {
	let result = position.col;
	for (let line = 0; line < position.line; line++) result += lines[line]!.length + 1;
	return result;
}

function withSelectionAnchor(node: NativeNode, anchor: number): NativeNode {
	if (node.k === "editor") return node.p ? { ...node, p: { ...node.p, anchor } } : node;
	if (!node.c) return node;
	return { ...node, c: node.c.map(child => "k" in child ? withSelectionAnchor(child, anchor) : child) };
}
function keyInput(key: KeyId): string | undefined {
	const parts = canonicalKeyId(key).split("+");
	const base = parts.pop() || "+";
	let modifier = 1;
	for (const part of parts) {
		if (part === "shift") modifier += 1;
		else if (part === "alt") modifier += 2;
		else if (part === "ctrl") modifier += 4;
		else if (part === "super") modifier += 8;
	}
	const arrows: Record<string, string> = { up: "A", down: "B", left: "D", right: "C", home: "H", end: "F" };
	if (arrows[base]) return `\x1b[1;${modifier}${arrows[base]}`;
	const tilde: Record<string, number> = {
		insert: 2, delete: 3, pageup: 5, pagedown: 6,
		f1: 11, f2: 12, f3: 13, f4: 14, f5: 15, f6: 17,
		f7: 18, f8: 19, f9: 20, f10: 21, f11: 23, f12: 24,
	};
	if (tilde[base]) return `\x1b[${tilde[base]};${modifier}~`;
	const named: Record<string, number> = { enter: 13, tab: 9, escape: 27, backspace: 127, space: 32 };
	const code = named[base] ?? ([...base].length === 1 ? base.codePointAt(0) : undefined);
	return code === undefined ? undefined : `\x1b[${code};${modifier}u`;
}

/** Compose with the actual CustomEditor instance, including an earlier extension's factory. */
function addKeyboardSelection(editor: CustomEditor): CustomEditor {
	const input = editor.handleInput.bind(editor);
	const render = editor.render.bind(editor);
	const describe = editor.describe.bind(editor);
	const nativeEvent = editor.handleNativeEvent.bind(editor);
	const decorate = editor.decorateText.bind(editor);
	const pasteText = editor.pasteText.bind(editor);
	const insertPaste = editor.insertPaste.bind(editor);
	const insertText = editor.insertText.bind(editor);
	const insertAtom = editor.insertAtom.bind(editor);
	let anchor: Position | undefined;
	let revision = editor.textRevision;
	let width = 80;
	let collecting: EditorTextDecorationContext[] | undefined;
	let firstVisualRow = false;
	let lastVisualRow = false;
	let bracketedPaste = false;
	let pasteTail = "";

	function clear(): void {
		if (!anchor) return;
		anchor = undefined;
		editor.invalidate();
	}
	function range(): { from: number; to: number } | undefined {
		if (revision !== editor.textRevision || editor.vimMode !== "insert" || editor.nativeKeyPassthrough) anchor = undefined;
		if (!anchor) return undefined;
		const lines = editor.getLines();
		const a = offset(lines, anchor);
		const b = offset(lines, editor.getCursor());
		if (a === b) return undefined;
		let from = Math.min(a, b);
		let to = Math.max(a, b);
		const pattern = editor.atomicTokenPattern;
		if (pattern) {
			let start = 0;
			for (const line of lines) {
				if (start <= to && start + line.length >= from) {
					const re = new RegExp(pattern.source, pattern.flags.includes("g") ? pattern.flags : `${pattern.flags}g`);
					for (const match of line.matchAll(re)) {
						const left = start + match.index;
						const right = left + match[0].length;
						if (left < from && from < right) from = left;
						if (left < to && to < right) to = right;
					}
				}
				start += line.length + 1;
				if (start > to) break;
			}
		}
		return { from, to };
	}
	function move(cursor: number): void {
		const len = editor.getText().length;
		editor.applyHostEdit({ from: cursor, to: cursor, text: "", cursor, len });
	}
	function replace(text: string): boolean {
		const selected = range();
		if (!selected) return false;
		clear();
		editor.applyHostEdit({ ...selected, text, cursor: selected.from + text.length, len: editor.getText().length });
		return true;
	}
	function snapAtomic(backward: boolean): void {
		const cursor = editor.getCursor();
		const line = editor.getLines()[cursor.line]!;
		const pattern = editor.atomicTokenPattern;
		if (!pattern) return;
		const re = new RegExp(pattern.source, pattern.flags.includes("g") ? pattern.flags : `${pattern.flags}g`);
		for (const match of line.matchAll(re)) {
			if (match.index < cursor.col && match.index + match[0].length > cursor.col) {
				move(offset(editor.getLines(), { line: cursor.line, col: backward ? match.index : match.index + match[0].length }));
				return;
			}
		}
	}
	function dismissAutocomplete(): void {
		const cursor = offset(editor.getLines(), editor.getCursor());
		editor.moveToLineStart();
		move(cursor);
	}

	editor.decorateText = (text, context) => {
		const selected = range();
		let result: string;
		if (!selected) result = decorate(text, context);
		else {
			const start = offset(editor.getLines(), { line: context.line, col: context.startCol });
			const from = Math.max(0, Math.min(text.length, selected.from - start));
			const to = Math.max(from, Math.min(text.length, selected.to - start));
			const part = (a: number, b: number) => decorate(text.slice(a, b), {
				...context, startCol: context.startCol + a, endCol: context.startCol + b,
			});
			result = part(0, from) + theme.inverse(part(from, to)) + part(to, text.length);
		}
		if (collecting) {
			const id = collecting.push(context) - 1;
			// Internal zero-width layout sentinels are removed before returning render output.
			// They associate the SDK's source segments with its actual wrapped rows, without
			// reproducing its wrapping algorithm or sending a terminal protocol to the user.
			result += `\x1b]133;codexpress-selection=${id}\x07`;
		}
		return result;
	};
	editor.render = columns => {
		width = columns;
		const segments: EditorTextDecorationContext[] = [];
		collecting = segments;
		let rows: readonly string[];
		try { rows = render(columns); }
		finally { collecting = undefined; }
		const cursorRow = rows.findIndex(row => row.includes(CURSOR_MARKER));
		const cursor = editor.getCursor();
		const lines = editor.getLines();
		firstVisualRow = cursor.line === 0 && cursor.col === 0;
		lastVisualRow = cursor.line === lines.length - 1 && cursor.col === lines[cursor.line]!.length;
		const clean = rows.map((row, rowIndex) => row.replace(/\x1b\]133;codexpress-selection=(\d+)\x07/g, (_, id: string) => {
			const segment = segments[Number(id)]!;
			if (rowIndex === cursorRow) {
				if (segment.line === 0 && segment.startCol === 0) firstVisualRow = true;
				if (segment.line === lines.length - 1 && segment.endCol === lines[segment.line]!.length) lastVisualRow = true;
			}
			return "";
		}));
		return clean;
	};
	editor.describe = context => {
		const node = describe(context);
		return range() && anchor ? withSelectionAnchor(node, offset(editor.getLines(), anchor)) : node;
	};
	editor.handleNativeEvent = event => {
		if (event.type === "edit" || event.type === "undo" || event.type === "send") clear();
		nativeEvent(event);
	};

	// Keep the SDK's paste storage, attachment conversion and large-paste menu. Its public
	// insertion APIs cannot share an undo transaction with applyHostEdit: replacing a
	// selection through these paths intentionally retains two native undo steps.
	editor.pasteText = (text, options) => { replace(""); pasteText(text, options); };
	editor.insertPaste = text => { replace(""); insertPaste(text); };
	editor.insertText = text => { if (!replace(text)) insertText(text); };
	editor.insertAtom = (label, expansion) => { replace(""); insertAtom(label, expansion); };

	editor.handleInput = data => {
		if (bracketedPaste || data.includes(BRACKETED_PASTE_START)) {
			const completed = (pasteTail + data).includes(BRACKETED_PASTE_END);
			bracketedPaste = !completed;
			pasteTail = completed ? "" : (pasteTail + data).slice(-(BRACKETED_PASTE_END.length - 1));
			input(data);
			return;
		}
		if (editor.pasteInFlight || editor.vimMode !== "insert" || editor.nativeKeyPassthrough) {
			input(data);
			return;
		}
		const parsed = parseKey(data);
		const canonical = parsed === undefined ? undefined : canonicalKeyId(parsed);
		const kb = getKeybindings();
		const matches = (action: Keybinding) => kb.matchesCanonical(canonical, action);
		range(); // Drop stale selection after a host-owned document edit.
		if (matchesKey(data, "ctrl+c")) { clear(); input(data); return; }
		if (canonical === "escape" && range()) { clear(); return; }
		if (matchesKey(data, "super+a")) {
			dismissAutocomplete();
			anchor = { line: 0, col: 0 };
			revision = editor.textRevision;
			editor.moveToMessageEnd();
			editor.invalidate();
			return;
		}
		const motion = selectionKeys.find(([, keys]) => keys.some(key => canonical === canonicalKeyId(key)))?.[0];
		if (motion) {
			const cursor = editor.getCursor();
			anchor ??= cursor;
			revision = editor.textRevision;
			const lines = editor.getLines();
			const line = lines[cursor.line]!;
			const at = offset(lines, cursor);
			if (motion === "up" || motion === "down") {
				// Only the host knows its word-wrapped rows and sticky visual column. The
				// render adapter distinguishes document boundaries, where ordinary Up/Down
				// would browse history or jump to line start/end instead of extending.
				if (editor.isAutocompleteActive()) dismissAutocomplete();
				editor.render(width);
				if (!(motion === "up" ? firstVisualRow : lastVisualRow)) {
					const action = motion === "up" ? "tui.editor.cursorUp" : "tui.editor.cursorDown";
					const sequence = kb.getKeys(action).map(keyInput).find(value => value !== undefined);
					if (sequence) Editor.prototype.handleInput.call(editor, sequence);
				}
			} else {
				dismissAutocomplete();
				if (motion === "start") editor.moveToLineStart();
				else if (motion === "end") editor.moveToLineEnd();
				else if (motion === "wordLeft") move(cursor.col === 0 ? Math.max(0, at - 1) : at - cursor.col + moveWordLeft(line, cursor.col));
				else if (motion === "wordRight") move(cursor.col === line.length ? Math.min(editor.getText().length, at + 1) : at - cursor.col + moveWordRight(line, cursor.col));
				else if (motion === "left") {
					let length = 1;
					for (const grapheme of getSegmenter().segment(line.slice(0, cursor.col))) length = grapheme.segment.length;
					move(Math.max(0, at - length));
				} else {
					const first = getSegmenter().segment(line.slice(cursor.col))[Symbol.iterator]().next().value;
					move(Math.min(editor.getText().length, at + (first?.segment.length ?? 1)));
				}
			}
			snapAtomic(motion === "left" || motion === "wordLeft" || motion === "up" || motion === "start");
			editor.invalidate();
			return;
		}
		const selected = range();
		if (!selected) { clear(); input(data); return; }
		if (matchesKey(data, "super+x") && editor.onYank) {
			editor.onYank(editor.getText().slice(selected.from, selected.to));
			replace("");
			return;
		}
		if (deleteActions.some(matches) || matchesKey(data, "shift+backspace") || matchesKey(data, "shift+delete")) {
			replace("");
			return;
		}
		if (matches("tui.editor.cursorLeft") || matches("tui.editor.cursorRight")) {
			clear();
			move(matches("tui.editor.cursorLeft") ? selected.from : selected.to);
			return;
		}
		const printable = extractPrintableText(data);
		if (printable !== undefined) { replace(printable); return; }
		if (
			navigationActions.some(matches) || matches("tui.editor.undo") || matches("tui.input.submit") ||
			matchesKey(data, "ctrl+a") || matchesKey(data, "ctrl+e")
		) clear();
		input(data);
	};
	return editor;
}

export function registerKeyboardSelection(pi: ExtensionAPI): void {
	const installed = new WeakSet<CustomEditor>();
	const factory: EditorFactory = tui => {
		const editor = tui.getFocused();
		if (!(editor instanceof CustomEditor)) throw new Error("未找到 OMP 原生输入框，无法启用键盘选区。");
		if (!installed.has(editor)) {
			addKeyboardSelection(editor);
			installed.add(editor);
		}
		return editor;
	};
	pi.on("session_start", (_event, ctx) => {
		if (!ctx.hasUI || ctx.ui.getEditorComponent() === factory) return;
		ctx.ui.setEditorComponent(factory);
	});
}
