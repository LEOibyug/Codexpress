import { randomUUID } from "node:crypto";
import { readFile, mkdir, writeFile } from "node:fs/promises";
import { createConnection } from "node:net";
import { homedir } from "node:os";
import { join } from "node:path";
import { getAgentDir, isRecord } from "@oh-my-pi/pi-utils";
import { parseGatewayModels } from "./models.js";
import type { CodexpressProfileConfig, Connection, GatewayBinding, ResolveConnection } from "./types.js";
import { readMacSelection } from "./mac-selection.js";
import { MAC_ROUTE_CREDENTIAL } from "./mac-transport.js";

type ResolveOptions = NonNullable<Parameters<ResolveConnection>[0]>;

function stateDirectory(config: CodexpressProfileConfig): string {
	return process.env.CODEXPRESS_STATE_DIR ?? config.stateDir ?? join(homedir(), "Library", "Application Support", "Codexpress");
}

export function normalizeBaseUrl(value: string): string {
	const url = new URL(value);
	if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) {
		throw new Error("Codexpress 地址必须为不含凭据、查询参数或片段的 HTTP(S) URL。");
	}
	return url.toString().replace(/\/+$/, "");
}

function isLoopbackHost(hostname: string): boolean {
	const normalized = hostname.replace(/^\[(.*)\]$/, "$1").toLowerCase();
	return normalized === "127.0.0.1" || normalized === "localhost" || normalized === "::1";
}

function toOmpBaseUrl(normalizedUrl: string): string {
	const url = new URL(normalizedUrl);
	if (url.pathname === "/v1") url.pathname = "/omp/v1";
	return url.toString().replace(/\/+$/, "");
}

class LocalControlUnavailableError extends Error {}

export function callLocalManagement<T>(
	stateDir: string,
	op: string,
	payload: Record<string, unknown> = {},
	signal?: AbortSignal,
): Promise<T> {
	signal?.throwIfAborted();
	const { promise, resolve, reject } = Promise.withResolvers<T>();
	const id = randomUUID();
	const socket = createConnection({ path: join(stateDir, "control.sock") });
	let buffer = "";
	let settled = false;
	const finish = (error?: Error, data?: T) => {
		if (settled) return;
		settled = true;
		signal?.removeEventListener("abort", abort);
		socket.destroy();
		if (error) reject(error);
		else resolve(data!);
	};
	const abort = () => finish(new Error("Codexpress 请求已取消。"));
	socket.setEncoding("utf8");
	socket.setTimeout(15_000, () => finish(new Error("Codexpress 本机请求超时。")));
	socket.once("connect", () => socket.write(`${JSON.stringify({ id, op, payload })}\n`));
	socket.on("data", chunk => {
		buffer += chunk;
		if (Buffer.byteLength(buffer) > 8 * 1024 * 1024) {
			finish(new Error("Codexpress 本机响应超出协议大小限制。"));
			return;
		}
		const end = buffer.indexOf("\n");
		if (end < 0) return;
		let response: unknown;
		try {
			response = JSON.parse(buffer.slice(0, end));
		} catch {
			finish(new Error("Codexpress 返回了无效的本机响应。"));
			return;
		}
		if (!isRecord(response) || response.id !== id || typeof response.ok !== "boolean") {
			finish(new Error("Codexpress 返回了不匹配或无效的本机响应。"));
			return;
		}
		if (!response.ok) {
			finish(new Error(typeof response.error === "string" ? response.error : "Codexpress 本机操作失败。"));
			return;
		}
		finish(undefined, response.data as T);
	});
	socket.once("error", error => {
		const code = (error as NodeJS.ErrnoException | undefined)?.code;
		const message = "无法连接本机 Codexpress，请先启动应用。";
		if (code === "ENOENT" || code === "ECONNREFUSED" || code === "ENOTSOCK") {
			finish(new LocalControlUnavailableError(message));
		} else {
			finish(new Error(message));
		}
	});
	socket.once("end", () => finish(new Error("Codexpress 在返回响应前关闭了连接。")));
	signal?.addEventListener("abort", abort, { once: true });
	if (signal?.aborted) abort();
	return promise;
}

function parseBinding(value: unknown): GatewayBinding {
	if (!isRecord(value) || value.provider !== "codexpress" || value.api !== "openai-codex-responses"
		|| typeof value.base_url !== "string" || typeof value.key !== "string" || !value.key
		|| typeof value.enabled !== "boolean" || typeof value.running !== "boolean" || !Array.isArray(value.models)) {
		throw new Error("Codexpress 返回了无效的绑定信息。");
	}
	const capabilities = isRecord(value.capabilities) ? value.capabilities : {};
	return {
		provider: "codexpress", api: "openai-codex-responses",
		base_url: normalizeBaseUrl(value.base_url), key: value.key,
		enabled: value.enabled, running: value.running,
		models: parseGatewayModels(value.models),
		capabilities: {
			websocket: typeof capabilities.websocket === "boolean" ? capabilities.websocket : null,
			remote_compaction_v2: typeof capabilities.remote_compaction_v2 === "boolean" ? capabilities.remote_compaction_v2 : null,
			legacy_budget_migration: typeof capabilities.legacy_budget_migration === "boolean" ? capabilities.legacy_budget_migration : null,
		},
	};
}

async function readProfile(profileDir: string): Promise<CodexpressProfileConfig> {
	let text: string;
	try {
		text = await readFile(join(profileDir, "codexpress.json"), "utf8");
	} catch (error) {
		if (isRecord(error) && error.code === "ENOENT") return {};
		throw error;
	}
	const value: unknown = JSON.parse(text);
	if (!isRecord(value) || (value.baseUrl !== undefined && typeof value.baseUrl !== "string")
		|| (value.stateDir !== undefined && typeof value.stateDir !== "string")) {
		throw new Error("当前 profile 的 codexpress.json 配置无效。");
	}
	return {
		...value,
		baseUrl: typeof value.baseUrl === "string" ? normalizeBaseUrl(value.baseUrl) : undefined,
		stateDir: typeof value.stateDir === "string" ? value.stateDir : undefined,
	};
}

export function createConnectionResolver(profileDir = getAgentDir()) {
	let cached: { stateDir: string; binding: GatewayBinding; expires: number } | undefined;
	let pending: { stateDir: string; promise: Promise<GatewayBinding> } | undefined;

	const getBinding = async (options: ResolveOptions = {}): Promise<GatewayBinding> => {
		options.signal?.throwIfAborted();
		const config = await readProfile(profileDir);
		const stateDir = stateDirectory(config);
		if (!options.activate && cached?.stateDir === stateDir && (options.reuseLocalBinding || cached.expires > Date.now())) return cached.binding;
		if (!options.activate && !options.signal && pending?.stateDir === stateDir) return pending.promise;
		const promise = callLocalManagement<unknown>(stateDir, options.activate ? "omp.bind" : "omp.binding", {}, options.signal)
			.then(value => {
				const binding = parseBinding(value);
				if (options.activate && (!binding.enabled || !binding.running)) throw new Error("Codexpress 未能启用 OMP 接口，原有登录未变更。");
				cached = { stateDir, binding, expires: Date.now() + 5_000 };
				return binding;
			});
		if (!options.activate && !options.signal) pending = { stateDir, promise };
		try {
			return await promise;
		} finally {
			if (pending?.promise === promise) pending = undefined;
		}
	};

	const resolveRemote = async (
		remoteUrl: string,
		config: CodexpressProfileConfig,
		options: ResolveOptions,
		persistBaseUrl: boolean,
	): Promise<Connection> => {
		const baseUrl = toOmpBaseUrl(normalizeBaseUrl(remoteUrl));
		const stored = options.key ?? await options.getKey?.();
		const key = !stored || stored === MAC_ROUTE_CREDENTIAL ? process.env.CODEXPRESS_API_KEY : stored;
		if (options.activate) {
			if (!key) throw new Error("登录远端 Codexpress 前请设置 CODEXPRESS_API_KEY。");
			const response = await fetch(`${baseUrl}/models`, {
				headers: { Authorization: `Bearer ${key}` },
				signal: options.signal ? AbortSignal.any([options.signal, AbortSignal.timeout(15_000)]) : AbortSignal.timeout(15_000),
			});
			if (!response.ok) throw new Error(`Codexpress 远端登录失败（HTTP ${response.status}），原有登录未变更。`);
			await response.body?.cancel();
			if (persistBaseUrl && config.baseUrl !== baseUrl) {
				await mkdir(profileDir, { recursive: true });
				await writeFile(join(profileDir, "codexpress.json"), `${JSON.stringify({ ...config, baseUrl }, null, 2)}\n`, { mode: 0o600 });
			}
		}
		return { baseUrl, key, local: false };
	};

	const resolveLocal = async (
		config: CodexpressProfileConfig,
		options: ResolveOptions,
		selected = false,
	): Promise<Connection> => {
		const binding = await getBinding(options);
		const stateDir = stateDirectory(config);
		const stored = !selected && (options.key ?? await options.getKey?.());
		return {
			baseUrl: binding.base_url,
			key: !stored || stored === MAC_ROUTE_CREDENTIAL ? binding.key : stored,
			...(selected ? { selection: "local" as const } : {}),
			local: true,
			stateDir,
			legacyBudgetMigration: binding.capabilities.legacy_budget_migration === true,
		};
	};

	const resolveConnection: ResolveConnection = async (options = {}) => {
		options.signal?.throwIfAborted();
		const config = await readProfile(profileDir);
		const explicitOmpUrl = process.env.CODEXPRESS_OMP_BASE_URL?.trim();
		if (explicitOmpUrl) {
			return await resolveRemote(explicitOmpUrl, config, options, true);
		}
		const envUrl = process.env.CODEXPRESS_BASE_URL?.trim();
		if (envUrl) {
			const normalizedEnv = normalizeBaseUrl(envUrl);
			const parsedEnv = new URL(normalizedEnv);
			const isLocalChatbotExport = parsedEnv.pathname === "/v1" && isLoopbackHost(parsedEnv.hostname);
			if (!isLocalChatbotExport) return await resolveRemote(normalizedEnv, config, options, true);
			if (config.baseUrl) return await resolveRemote(config.baseUrl, config, options, false);
		}
		if (config.baseUrl) {
			return await resolveRemote(config.baseUrl, config, options, true);
		}
		const selected = await readMacSelection(stateDirectory(config));
		if (selected?.mode === "remote") return { local: false, selection: "remote", baseUrl: selected.baseUrl,
			instanceId: selected.instanceId, key: selected.key };
		if (selected) return resolveLocal(config, options, true);
		if (envUrl) {
			try { return await resolveLocal(config, options); }
			catch (error) {
				if (error instanceof LocalControlUnavailableError) return resolveRemote(envUrl, config, options, false);
				throw error;
			}
		}
		return await resolveLocal(config, options);
	};

	return {
		resolveConnection,
		getBinding,
		invalidate() { cached = undefined; },
	};
}

export async function discoverGatewayModels(connection: Connection, signal?: AbortSignal) {
	const response = await fetch(`${connection.baseUrl}/models`, {
		headers: connection.key ? { Authorization: `Bearer ${connection.key}` } : {},
		redirect: "error",
		signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(15_000)]) : AbortSignal.timeout(15_000),
	});
	if (!response.ok) throw new Error(`Codexpress 模型发现失败（HTTP ${response.status}）。`);
	const data: unknown = await response.json();
	if (connection.selection === "remote") {
		if (!isRecord(data) || !Array.isArray(data.models)) throw new Error("Codexpress 返回了无效的远端模型目录。");
		return parseGatewayModels(data.models.map(row => {
			if (!isRecord(row)) throw new Error("Codexpress 远端目录中的模型无效。");
			const efforts = Array.isArray(row.supported_reasoning_levels)
				? row.supported_reasoning_levels.map(item => isRecord(item) ? item.effort : item).filter(item => typeof item === "string") : undefined;
			return { ...row, id: row.slug, name: row.display_name, input: row.input_modalities,
				...(efforts ? { reasoning: efforts.length > 0, thinking: row.thinking ?? { mode: "effort", efforts } } : {}) };
		}));
	}
	if (!isRecord(data) || !Array.isArray(data.data)) throw new Error("Codexpress 返回了无效的模型目录。");
	return parseGatewayModels(data.data);
}

/** Read only the gateway's committed budget version, without discovering models or usage. */
export async function fetchBudgetRevision(connection: Connection, signal?: AbortSignal): Promise<string> {
	if (connection.selection === "remote") throw new Error("所选远端网关不提供 OMP 预算版本。");
	let value: unknown;
	if (connection.local && connection.stateDir) {
		value = await callLocalManagement(connection.stateDir, "omp.budgets.revision", {}, signal);
	} else {
		const response = await fetch(`${connection.baseUrl}/budgets/revision`, {
			headers: connection.key ? { Authorization: `Bearer ${connection.key}` } : {},
			signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(15_000)]) : AbortSignal.timeout(15_000),
		});
		if (!response.ok) throw new Error(`Codexpress 预算版本读取失败（HTTP ${response.status}）。`);
		value = await response.json();
	}
	if (!isRecord(value) || typeof value.revision !== "string" || !value.revision) {
		throw new Error("Codexpress 返回了无效的预算版本。");
	}
	return value.revision;
}
