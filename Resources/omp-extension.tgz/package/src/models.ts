import { THINKING_EFFORTS } from "@oh-my-pi/pi-catalog/effort";
import { getBundledModel } from "@oh-my-pi/pi-catalog/models";
import { isRecord } from "@oh-my-pi/pi-utils";
import type { Connection, CodexpressProviderModel, GatewayModel } from "./types.js";

// These are the host's client-side budgeting defaults, not upstream model limits.
const OMP_DEFAULT_CONTEXT_WINDOW = 128_000;
const OMP_DEFAULT_MAX_TOKENS = 16_384;

export function parseGatewayModels(values: unknown[]): GatewayModel[] {
	return values.map(value => {
		if (!isRecord(value) || typeof value.id !== "string" || !value.id) {
			throw new Error("Codexpress 返回的模型缺少有效 ID。");
		}
		const model: GatewayModel = { id: value.id };
		if (typeof value.name === "string") model.name = value.name;
		if (typeof value.reasoning === "boolean") model.reasoning = value.reasoning;
		if (typeof value.remote_compaction === "boolean") model.remote_compaction = value.remote_compaction;
		if (typeof value.context_window === "number" && value.context_window > 0) model.context_window = value.context_window;
		if (typeof value.max_context_window === "number" && Number.isSafeInteger(value.max_context_window) && value.max_context_window > 0) {
			model.max_context_window = value.max_context_window;
		}
		if (value.auto_compact_token_limit === null) model.auto_compact_token_limit = null;
		else if (typeof value.auto_compact_token_limit === "number" && Number.isSafeInteger(value.auto_compact_token_limit)
			&& value.auto_compact_token_limit > 0) model.auto_compact_token_limit = value.auto_compact_token_limit;
		if (typeof value.max_output_tokens === "number" && value.max_output_tokens > 0) model.max_output_tokens = value.max_output_tokens;
		if (Array.isArray(value.input)) {
			model.input = value.input.filter((input): input is "text" | "image" => input === "text" || input === "image");
		}
		switch (value.kind) {
			case "text": model.kind = "chat"; break;
			case "chat": case "tiny": case "image": case "tts": case "stt": case "search":
			case "judge": case "embedding": case "rerank": case "video": model.kind = value.kind;
		}
		const cost = value.cost ?? value.pricing;
		if (isRecord(cost) && typeof cost.input === "number" && typeof cost.output === "number"
			&& typeof cost.cacheRead === "number" && typeof cost.cacheWrite === "number") {
			model.cost = { input: cost.input, output: cost.output, cacheRead: cost.cacheRead, cacheWrite: cost.cacheWrite };
		}
		if (isRecord(value.thinking)) {
			const thinking = value.thinking;
			const advertised = thinking.efforts;
			const efforts = Array.isArray(advertised)
				? THINKING_EFFORTS.filter(effort => advertised.includes(effort)) : [];
			if ((thinking.mode === "effort" || thinking.mode === "budget" || thinking.mode === "google-level"
				|| thinking.mode === "anthropic-adaptive" || thinking.mode === "anthropic-budget-effort") && efforts.length) {
				model.thinking = { ...thinking, mode: thinking.mode, efforts };
			}
		}
		return model;
	});
}

export function createProviderModels(models: GatewayModel[], connection: Connection): CodexpressProviderModel[] {
	return models.map(model => {
		const reference = getBundledModel("openai-codex", model.id)
			?? getBundledModel("openai", model.id)
			?? getBundledModel("google", model.id);
		const cost = model.cost ?? model.pricing ?? reference?.cost;
		const contextWindow = model.context_window ?? reference?.contextWindow ?? OMP_DEFAULT_CONTEXT_WINDOW;
		const remoteCompactionEnabled = model.remote_compaction !== false;
		return {
			id: model.id,
			name: model.name ?? reference?.name ?? model.id,
			api: "openai-codex-responses",
			kind: model.kind ?? reference?.kind ?? "chat",
			reasoning: model.reasoning ?? reference?.reasoning ?? false,
			thinking: model.thinking ?? reference?.thinking,
			input: model.input?.length ? model.input : reference?.input ?? ["text"],
			contextWindow,
			...(model.max_context_window ? { maxContextWindow: Math.max(contextWindow, model.max_context_window) } : {}),
			maxTokens: model.max_output_tokens ?? reference?.maxTokens ?? OMP_DEFAULT_MAX_TOKENS,
			cost: cost ?? { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
			preferWebsockets: false,
			remoteCompaction: {
				enabled: remoteCompactionEnabled,
				api: "openai-codex-responses",
				v2StreamingEnabled: remoteCompactionEnabled,
				v2Endpoint: `${connection.baseUrl}/codex/responses`,
				endpoint: `${connection.baseUrl}/codex/responses/compact`,
			},
		};
	});
}
