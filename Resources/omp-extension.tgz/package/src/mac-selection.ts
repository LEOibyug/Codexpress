import { constants } from "node:fs";
import { lstat, open } from "node:fs/promises";
import { join } from "node:path";
import { isRecord } from "@oh-my-pi/pi-utils";

export type MacSelection = { mode: "local" } | { mode: "remote"; baseUrl: string; instanceId: string; key: string };
export class MacSelectionError extends Error {}

/** Only the Mac inference handoff is a credential source; never open its management or device inventory. */
export async function readMacSelection(directory: string): Promise<MacSelection | undefined> {
	if (process.platform !== "darwin") return undefined;
	const invalid = () => new MacSelectionError("Codexpress 网关选择文件无效或权限不安全；请在 Mac 应用中重新选择网关。");
	const parent = await lstat(directory).catch(error => { if (!isRecord(error) || error.code !== "ENOENT") throw invalid(); });
	if (!parent) return undefined;
	if (!parent.isDirectory()) throw invalid();
	// O_NOFOLLOW rejects even a dangling final symlink; NONBLOCK avoids hanging on a FIFO.
	const file = await open(join(directory, "gateway-integrations.json"), constants.O_RDONLY | constants.O_NOFOLLOW | constants.O_NONBLOCK)
		.catch(error => { if (!isRecord(error) || error.code !== "ENOENT") throw invalid(); });
	if (!file) return undefined;
	try {
		const stat = await file.stat();
		const uid = process.getuid!();
		if (parent.uid !== uid || (parent.mode & 0o7777) !== 0o700 || !stat.isFile() || stat.nlink !== 1 || stat.uid !== uid
			|| (stat.mode & 0o7777) !== 0o600 || stat.size > 8192) throw invalid();
		let value: unknown;
		try { value = JSON.parse(await file.readFile("utf8")); } catch { throw invalid(); }
		const current = await lstat(directory);
		if (current.dev !== parent.dev || current.ino !== parent.ino || current.mode !== parent.mode || current.uid !== uid) throw invalid();
		if (!isRecord(value) || value.version !== 1) throw invalid();
		if (value.mode === "local" && Object.keys(value).length === 2) return { mode: "local" };
		if (value.mode !== "remote" || Object.keys(value).some(key => !["version", "mode", "endpoint", "instance_id", "device_key"].includes(key))
			|| typeof value.endpoint !== "string" || /[^\x21-\x7e]|%/.test(value.endpoint) || !/^https:\/\/[^\s/?#@\\]+\/?$/.test(value.endpoint)
			|| typeof value.instance_id !== "string" || !/^[\x21-\x7e]{1,256}$/.test(value.instance_id)) throw invalid();
		let endpoint: URL;
		try { endpoint = new URL(value.endpoint); } catch { throw invalid(); }
		if (endpoint.pathname !== "/" || endpoint.username || endpoint.password || endpoint.port === "0" || /:\/?$/.test(value.endpoint)) throw invalid();
		if (value.device_key === undefined) throw new MacSelectionError("当前远端网关没有 OMP 设备 Key；请在 Mac 的 Codexpress 中完成设备授权。");
		if (typeof value.device_key !== "string" || !/^cxr-[\da-fA-F]{64}$/.test(value.device_key)) throw invalid();
		return { mode: "remote", baseUrl: `${endpoint.origin}/v1`, instanceId: value.instance_id, key: value.device_key };
	} catch (error) {
		throw error instanceof MacSelectionError ? error : invalid();
	} finally { await file.close(); }
}
