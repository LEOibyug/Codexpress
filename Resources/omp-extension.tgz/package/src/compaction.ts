import { randomUUID } from "node:crypto";
import { mkdir, readFile, rename, unlink, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";
import type { ExtensionContext } from "@oh-my-pi/pi-coding-agent";
import type { Settings } from "@oh-my-pi/pi-coding-agent/config/settings";
import { matchModelCompactionThreshold, parseModelCompactionEntry } from "@oh-my-pi/pi-coding-agent/config/compaction-threshold";
import {
	cfgCompactionModelThresholds,
	cfgCompactionThresholdPercent,
	cfgCompactionThresholdTokens,
} from "@oh-my-pi/pi-coding-agent/session/context-settings";
import { isRecord } from "@oh-my-pi/pi-utils";
import type { GatewayModel } from "./types.js";

const pending = new Map<string, Promise<void>>();
type ModelBudgetContext = Pick<ExtensionContext, "model" | "modelRegistry">;

/** Persist only entries we still own; never write a merged project/runtime settings snapshot. */
export function syncGatewayCompaction(models: GatewayModel[], scope: Settings, profileDir: string, ctx?: ModelBudgetContext, signal?: AbortSignal): Promise<void> {
	// A derived subagent inherits its parent's defaults, but must not persist its injected policy.
	if (scope.overlayLayers().derived || resolve(scope.getAgentDir()) !== resolve(profileDir)) return Promise.resolve();
	const previous = pending.get(profileDir) ?? Promise.resolve();
	const next = previous.catch(() => {}).then(() => synchronize(models, scope, profileDir, ctx, signal));
	pending.set(profileDir, next);
	return next.finally(() => { if (pending.get(profileDir) === next) pending.delete(profileDir); });
}

async function synchronize(models: GatewayModel[], scope: Settings, profileDir: string, ctx?: ModelBudgetContext, signal?: AbortSignal): Promise<void> {
	signal?.throwIfAborted();
	const path = join(profileDir, "codexpress-compaction.json");
	const raw = await readFile(path, "utf8").catch(error => {
		if (isRecord(error) && error.code === "ENOENT") return "{}";
		throw error;
	});
	signal?.throwIfAborted();
	const saved: unknown = JSON.parse(raw);
	if (!isRecord(saved)) throw new Error("Codexpress 自动压缩点记录格式无效。");
	const managed: Record<string, string | number | null> = {};
	for (const [key, value] of Object.entries(saved)) {
		if (key.startsWith("codexpress/") && (value === null
			|| ((typeof value === "string" || typeof value === "number") && parseModelCompactionEntry(value)))) managed[key] = value;
	}
	const global = scope.getGlobalSettings();
	const compaction = isRecord(global.compaction) ? global.compaction : {};
	const globalEntries = isRecord(compaction.modelThresholds) ? compaction.modelThresholds : {};
	const effective = { ...cfgCompactionModelThresholds.get(scope) };
	// Exclude owned exact and wildcard entries; only an operator's policy beats gateway defaults.
	for (const [key, value] of Object.entries(managed)) {
		if (globalEntries[key] === value && effective[key] === value) delete effective[key];
	}
	const explicitGlobal = cfgCompactionThresholdPercent.get(scope) > 0 || cfgCompactionThresholdTokens.get(scope) > 0;
	let changed = false;
	const advertised = new Map(models.map(model => [`codexpress/${model.id}`, model]));
	for (const key of new Set([...Object.keys(managed), ...advertised.keys()])) {
		const model = advertised.get(key);
		// An old gateway provides no policy information: retain its last successful policy.
		if (model && model.auto_compact_token_limit === undefined) continue;
		const old = managed[key];
		const current = globalEntries[key];
		const desired = model && model.kind !== "image" && model.auto_compact_token_limit
			&& !explicitGlobal && !matchModelCompactionThreshold(effective, { provider: "codexpress", id: model.id })
			? `f${model.auto_compact_token_limit}` : undefined;
		if (old !== undefined && current !== old) {
			// Keep the ownership record while advertised, including a manual deletion, so it cannot be reacquired.
			if (!model || model.auto_compact_token_limit === null) delete managed[key];
			continue;
		}
		if (old === undefined && Object.hasOwn(globalEntries, key)) continue;
		if (desired !== current && (desired !== undefined || old !== undefined)) {
			// The host's threshold listener can otherwise reselect the old extended window and close a live Codex thread.
			if (ctx) refreshActiveModelBudget(ctx, scope.overlay({ "compaction.modelThresholds": { [key]: desired ?? null } }));
			cfgCompactionModelThresholds.setEntry(scope, key, desired);
			changed = true;
		}
		if (desired === undefined) delete managed[key];
		else managed[key] = desired;
	}
	if (JSON.stringify(saved) === JSON.stringify(managed)) return;
	if (changed) await scope.flush();
	await mkdir(profileDir, { recursive: true });
	const temporary = join(profileDir, `.codexpress-compaction-${randomUUID()}.json`);
	try {
		await writeFile(temporary, `${JSON.stringify(managed, null, 2)}\n`, { mode: 0o600 });
		await rename(temporary, path);
	} catch (error) {
		await unlink(temporary).catch(() => {});
		throw error;
	}
}

/** Refresh public budget metadata without selecting a model or closing the native provider session. */
export function refreshActiveModelBudget(ctx: ModelBudgetContext, scope: Settings): void {
	const active = ctx.model;
	if (active?.provider !== "codexpress") return;
	const registered = ctx.modelRegistry.find(active.provider, active.id);
	if (!registered) return;
	const effective = ctx.modelRegistry.fitContextWindow(registered, scope);
	active.contextWindow = effective.contextWindow;
	active.maxTokens = effective.maxTokens;
}
