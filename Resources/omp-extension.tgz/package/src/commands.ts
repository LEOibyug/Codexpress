import type { ExtensionAPI, ExtensionCommandContext } from "@oh-my-pi/pi-coding-agent";
import { matchesKey, Text } from "@oh-my-pi/pi-tui";
import { sanitizeText } from "@oh-my-pi/pi-utils";
import { callLocalManagement } from "./connection";
import { fetchCodexpressStatus, quotaReference, quotaWindowLabel, type GatewayStatus, type SourceStatus } from "./usage";
import type { Connection, ResolveConnection } from "./types";

interface CommandOptions {
	resolveConnection: ResolveConnection;
	refresh: (connection?: Connection, ctx?: ExtensionCommandContext) => Promise<void>;
}

const actions = [
	["status", "查看来源、余额与额度"],
	["connect", "重新绑定与刷新模型"],
	["takeover", "抢占来源"],
	["cancel", "停止抢占"],
	["recover", "恢复来源"],
	["balances", "主动更新余额"],
	["quotas", "主动更新官方额度与重置卡"],
	["billing", "主动核对账单"],
	["reset", "使用重置卡（在 Codexpress 确认）"],
] as const;

async function management<T>(connection: Connection, op: string, path: string, payload: Record<string, unknown> = {}, method = "POST"): Promise<T> {
	if (connection.selection === "remote") throw new Error("请在 Mac 的 Codexpress 中管理所选远端网关。");
	if (connection.local && connection.stateDir) return callLocalManagement<T>(connection.stateDir, op, payload);
	const baseUrl = process.env.CODEXPRESS_MANAGEMENT_BASE_URL?.replace(/\/+$/, "");
	const key = process.env.CODEXPRESS_MANAGEMENT_API_KEY;
	if (!baseUrl || !key) throw new Error("远端管理需要设置 CODEXPRESS_MANAGEMENT_BASE_URL 与独立的 CODEXPRESS_MANAGEMENT_API_KEY；也可在 Codexpress 中操作。");
	const response = await fetch(`${baseUrl}${path}`, {
		method, headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
		...(method === "GET" ? {} : { body: JSON.stringify(payload) }), signal: AbortSignal.timeout(15_000),
	});
	const result = await response.json() as T & { error?: { message?: string } };
	if (!response.ok) throw new Error(result.error?.message ?? `Codexpress 管理操作失败（${response.status}）。`);
	return result;
}

async function chooseSource(sources: SourceStatus[], query: string, ctx: ExtensionCommandContext): Promise<SourceStatus | undefined> {
	if (query) {
		const byId = sources.find(source => source.id === query);
		if (byId) return byId;
		const matches = sources.filter(source => source.name === query);
		if (matches.length === 1) return matches[0];
		if (!matches.length) throw new Error(`找不到来源：${query}`);
		sources = matches;
	}
	if (!sources.length) throw new Error("没有可操作的来源。");
	if (!ctx.hasUI) throw new Error("请在命令后填写来源 ID。");
	const labels = sources.map(source => `${source.name} [${source.id}]`);
	const selected = await ctx.ui.select("选择来源", labels);
	return selected === undefined ? undefined : sources[labels.indexOf(selected)];
}

function sourceKindLabel(kind: string): string {
	switch (kind) {
		case "official": return "官方账号";
		case "openai": return "OpenAI API Platform";
		case "google": return "Google AI Studio";
		case "api": return "Responses API";
		default: return kind;
	}
}

function sourceSummary(source: SourceStatus, paint: (tone: "dim" | "warning" | "error", text: string) => string = (_tone, text) => text): string {
	const details = [sourceKindLabel(source.kind), source.enabled ? source.health : "已停用"];
	if (source.active_requests) details.push(`${source.active_requests} 个请求进行中`);
	if (source.balance?.amount !== undefined && source.balance.amount !== null) details.push(`余额 ${source.balance.currency ?? ""} ${source.balance.amount}${source.balance.estimated ? "（估算）" : ""}`);
	if (typeof source.credits?.available_count === "number") details.push(`${source.credits.available_count} 张重置卡`);
	const lines = [sanitizeText(`${source.name} [${source.id}]`), `  ${sanitizeText(details.join("；"))}`];
	for (const window of source.quota?.windows ?? []) {
		const reference = quotaReference(source, window);
		const known = typeof window.used_percent === "number" && Number.isFinite(window.used_percent);
		if (!known && !reference && !window.window_seconds) continue;
		const quota = `  ${sanitizeText(quotaWindowLabel(window))} ${known ? `剩余 ${Math.max(0, 100 - window.used_percent!)}%` : "额度未知"}`;
		const ref = reference ? paint(reference.tone, reference.text) : "";
		lines.push(`${quota}${reference && !reference.below ? ` · ${ref}` : ""}`);
		if (reference?.below) lines.push(`    ${ref}`);
	}
	return lines.join("\n");
}

async function showStatus(snapshot: GatewayStatus, ctx: ExtensionCommandContext): Promise<void> {
	const title = `Codexpress · ${snapshot.inflight} 个进行中的请求`;
	if (!ctx.hasUI) {
		ctx.ui.notify([title, ...snapshot.sources.map(source => sourceSummary(source))].join("\n"), "info");
		return;
	}
	await ctx.ui.custom<void>((tui, theme, _keys, done) => {
		const body = new Text([title, ...snapshot.sources.map(source => sourceSummary(source, (tone, text) => theme.fg(tone, text)))].join("\n\n"), 1, 0);
		const timer = setInterval(() => {
			body.setText([title, ...snapshot.sources.map(source => sourceSummary(source, (tone, text) => theme.fg(tone, text)))].join("\n\n"));
			tui.requestRender();
		}, 60_000);
		let offset = 0;
		let lastMaximum = 0;
		return {
			render(width: number) {
				const rows = body.render(width);
				const height = Math.max(1, tui.terminal.rows - 4);
				lastMaximum = Math.max(0, rows.length - height);
				offset = Math.min(offset, lastMaximum);
				return [...rows.slice(offset, offset + height), theme.fg("dim", " ↑↓ / PgUp PgDn 滚动 · Enter / Esc 关闭")];
			},
			invalidate() { body.invalidate(); },
			dispose() { clearInterval(timer); },
			handleInput(data: string) {
				if (matchesKey(data, "escape") || matchesKey(data, "enter")) { done(); return; }
				if (matchesKey(data, "up")) offset = Math.max(0, offset - 1);
				else if (matchesKey(data, "down")) offset = Math.min(lastMaximum, offset + 1);
				else if (matchesKey(data, "pageUp")) offset = Math.max(0, offset - Math.max(1, tui.terminal.rows - 4));
				else if (matchesKey(data, "pageDown")) offset = Math.min(lastMaximum, offset + Math.max(1, tui.terminal.rows - 4));
				tui.requestRender();
			},
		};
	});
}

export function registerCodexpressCommands(pi: ExtensionAPI, options: CommandOptions): void {
	pi.registerCommand("codexpress", {
		description: "连接 Codexpress、查看来源与用量、抢占及主动刷新",
		getArgumentCompletions: prefix => actions.filter(([name]) => name.startsWith(prefix)).map(([value, description]) => ({ value, label: value, description })),
		async handler(args, ctx) {
			try {
				const [requested, ...rest] = args.trim().split(/\s+/);
				let action = requested;
				if (!action && ctx.hasUI) {
					const selected = await ctx.ui.select("Codexpress", actions.map(([, label]) => label));
					if (!selected) return;
					action = actions.find(([, label]) => label === selected)?.[0] ?? "status";
				}
				action ||= "status";
				if (action === "connect") {
					const current = await options.resolveConnection({ refreshCapabilities: true });
					if (current.selection === "remote") {
						await options.refresh(current, ctx);
						ctx.ui.notify("已刷新 Mac 所选远端网关的模型目录。", "info");
						return;
					}
					await ctx.modelRegistry.authStorage.oauth.login("codexpress", {
						onAuth: info => ctx.ui.notify(info.url, "info"),
						onPrompt: prompt => ctx.ui.input(prompt.message, prompt.placeholder, { secret: prompt.secret }).then(value => value ?? ""),
						onProgress: message => ctx.ui.notify(message, "info"),
					});
					await options.refresh(await options.resolveConnection({ getKey: () => ctx.modelRegistry.getApiKeyForProvider("codexpress") }), ctx);
					ctx.ui.notify("已绑定 Codexpress；模型列表已更新。", "info");
					return;
				}
				const connection = await options.resolveConnection({ getKey: () => ctx.modelRegistry.getApiKeyForProvider("codexpress") });
				if (connection.selection === "remote") throw new Error("请在 Mac 的 Codexpress 中查看状态或管理所选远端网关。");
				const snapshot = connection.local && connection.stateDir
					? await callLocalManagement<GatewayStatus>(connection.stateDir, "status")
					: await fetchCodexpressStatus(connection);
				if (action === "status") {
					await showStatus(snapshot, ctx);
					return;
				}
				if (action === "cancel") {
					if (!snapshot.manual_route?.id) throw new Error("当前没有手动抢占。");
					await management(connection, "routing.cancel", "/routing/cancel", { id: snapshot.manual_route.id });
					ctx.ui.notify("已停止抢占。", "info");
					return;
				}
				if (action === "billing" || action === "balances" || action === "quotas") {
					const balanceCandidates = action === "quotas"
						? snapshot.sources.filter(source => source.kind === "official")
						: snapshot.sources.filter(source => source.kind === "api");
					const source = rest.length ? await chooseSource(balanceCandidates, rest.join(" "), ctx) : undefined;
					const payload = source ? { source_id: source.id } : {};
					const op = action === "billing" ? "usage.reconcile" : `control.refresh.${action}`;
					await management(connection, op, `/refresh/${action}`, payload);
					ctx.ui.notify("已提交更新；稍后可通过 /usage 查看最新数据。", "info");
					return;
				}
				if (action !== "takeover" && action !== "recover" && action !== "reset") throw new Error(`可用命令：${actions.map(([name]) => name).join("、")}`);
				const source = await chooseSource(action === "reset" ? snapshot.sources.filter(source => source.kind === "official") : snapshot.sources, rest.join(" "), ctx);
				if (!source) return;
				if (action === "reset") {
					const result = await management<{ id: string; status: string }>(connection, "control.reset.request", "/credits/reset-requests", { source_id: source.id, request_id: crypto.randomUUID() });
					ctx.ui.notify(`重置请求 ${result.id} 已提交；请在 Codexpress 窗口中确认。`, "info");
					return;
				}
				await management(connection, action === "takeover" ? "routing.try" : "routing.recover", `/routing/${action}`, { source_id: source.id });
				ctx.ui.notify(action === "takeover" ? `已抢占 ${source.name}。` : `已恢复 ${source.name}。`, "info");
			} catch (error) {
				ctx.ui.notify(error instanceof Error ? error.message : String(error), "error");
			}
		},
	});
}
