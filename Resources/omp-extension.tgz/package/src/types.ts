import type { ProviderModelConfig } from "@oh-my-pi/pi-coding-agent";
import type { RemoteCompactionConfig } from "@oh-my-pi/pi-ai";

export interface Connection {
	baseUrl: string;
	key?: string;
	local: boolean;
	stateDir?: string;
	legacyBudgetMigration?: boolean;
}

export type ResolveConnection = (options?: {
	activate?: boolean;
	signal?: AbortSignal;
	key?: string;
}) => Promise<Connection>;

export interface GatewayModel {
	id: string;
	name?: string;
	kind?: ProviderModelConfig["kind"];
	context_window?: number | null;
	max_context_window?: number | null;
	auto_compact_token_limit?: number | null;
	max_output_tokens?: number | null;
	reasoning?: boolean;
	input?: ProviderModelConfig["input"];
	thinking?: ProviderModelConfig["thinking"];
	cost?: ProviderModelConfig["cost"] | null;
	pricing?: ProviderModelConfig["cost"] | null;
}

export interface GatewayBinding {
	provider: "codexpress";
	api: "openai-codex-responses";
	base_url: string;
	key: string;
	enabled: boolean;
	running: boolean;
	models: GatewayModel[];
	capabilities: {
		websocket: boolean | null;
		remote_compaction_v2: boolean | null;
		legacy_budget_migration: boolean | null;
	};
}

// OMP 19 accepts remoteCompaction but omits it from the public registration type.
export type CodexpressProviderModel = ProviderModelConfig & {
	// Consumed by OMP's public custom-model overlay, but missing from ProviderModelConfig in 19.0.
	maxContextWindow?: number;
	remoteCompaction: RemoteCompactionConfig<"openai-codex-responses">;
};

export interface CodexpressProfileConfig {
	baseUrl?: string;
	stateDir?: string;
}
