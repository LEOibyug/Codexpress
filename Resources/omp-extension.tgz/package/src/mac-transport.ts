import { randomBytes } from "node:crypto";
import type { ResolveConnection } from "./types.js";

// The SDK requires a credential even for its private loopback hop. This reference is not a gateway key.
export const MAC_ROUTE_CREDENTIAL = "codexpress-mac-selection";

export interface MacTransport {
	baseUrl: string;
	close(): Promise<void>;
}

/** Native compaction bypasses extension stream handlers. Give all SDK paths the same request-time credential boundary. */
export function openMacTransport(resolveConnection: ResolveConnection): MacTransport {
	const prefix = `/${randomBytes(32).toString("hex")}/v1`;
	const paths = new Map([
		[`${prefix}/responses`, "generate"], [`${prefix}/codex/responses`, "generate"],
		[`${prefix}/responses/compact`, "compact"], [`${prefix}/codex/responses/compact`, "compact"],
		[`${prefix}/v2/codex/responses`, "compact-v2"],
	]);
	const server = Bun.serve({ hostname: "127.0.0.1", port: 0, idleTimeout: 0,
		async fetch(request, listener) {
			const url = new URL(request.url);
			const operation = paths.get(url.pathname);
			if (request.method !== "POST" || request.headers.get("host") !== `127.0.0.1:${listener.port}`
				|| request.headers.has("origin") || url.search || !operation) return new Response(null, { status: 403 });
			let next;
			try { next = await resolveConnection({ signal: request.signal }); }
			catch { return new Response("Mac 上的网关或设备授权不可用。", { status: 403 }); }
			if ((!next.selection && !next.local) || !next.key) return new Response(null, { status: 403 });
			if (!next.local && operation === "compact-v2") return new Response(null, { status: 501 });
			const headers = new Headers({ "content-type": "application/json", authorization: `Bearer ${next.key}` });
			// Never copy the host's bearer, cookies, account/attestation, proxy or arbitrary model headers.
			for (const name of next.local ? ["accept", "session_id", "session-id", "conversation_id", "thread-id", "x-codex-turn-metadata", "openai-beta"] : ["accept"]) {
				const value = request.headers.get(name);
				if (value) headers.set(name, value);
			}
			const endpoint = `${next.baseUrl}${next.local ? "/codex" : ""}/responses${operation === "compact" ? "/compact" : ""}`;
			// One immutable address/key pair per HTTP request. Never retry a stream on a replacement target.
			try {
				const upstream = await fetch(endpoint, { method: "POST", body: request.body, headers, signal: request.signal, redirect: "error" });
				if (!next.local && (upstream.status === 401 || upstream.status === 403)) {
					await upstream.body?.cancel();
					return Response.json({ error: { message: "所选网关拒绝了 OMP 设备 Key。请在 Mac 的 Codexpress 中核对设备授权；扩展不会自动申请新 Key。" } }, { status: upstream.status });
				}
				const responseHeaders = new Headers();
				for (const name of ["content-type", "retry-after", "x-request-id"]) {
					const value = upstream.headers.get(name);
					if (value) responseHeaders.set(name, value);
				}
				return new Response(upstream.body, { status: upstream.status, headers: responseHeaders });
			} catch { return new Response("Codexpress 网关请求未完成。", { status: 502 }); }
		},
	});
	server.unref();
	return { baseUrl: `http://127.0.0.1:${server.port}${prefix}`, close: () => server.stop(true) };
}
