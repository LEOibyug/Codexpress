import { createHash, randomBytes } from "node:crypto";
import { isRecord } from "@oh-my-pi/pi-utils";
import { supportsRemoteV2 } from "./connection.js";
import { usesClassicResponses, type Connection, type ResolveConnection } from "./types.js";

export interface MacTransport {
	baseUrl: string;
	directV2Endpoint(target: Connection): string;
	close(): Promise<void>;
}

const sessionHeaders = ["session-id", "session_id", "x-session-id", "thread-id", "thread_id"];
const nativeHeaders = ["accept", ...sessionHeaders, "conversation_id", "x-codex-turn-metadata", "openai-beta"];

// Match the gateway's identity precedence; cache affinity headers are not conversation IDs.
function wireSession(body: Record<string, unknown>, headers: Headers): string | undefined {
	const metadata = isRecord(body.client_metadata) ? body.client_metadata : {};
	for (const id of [metadata.codexpress_session_id, metadata.session_id]) if (typeof id === "string") return id;
	const turn = headers.get("x-codex-turn-metadata");
	if (turn) {
		try {
			const data: unknown = JSON.parse(turn);
			if (isRecord(data) && typeof data.session_id === "string" && data.session_id && Buffer.byteLength(data.session_id) <= 512) return data.session_id;
		} catch { /* Old SDKs may only send a session header. */ }
	}
	for (const name of sessionHeaders) {
		const id = headers.get(name);
		if (id !== null) return id;
	}
}

/** Native compaction bypasses extension stream handlers. Give all SDK paths the same request-time credential boundary. */
export function openMacTransport(resolveConnection: ResolveConnection): MacTransport {
	const prefix = `/${randomBytes(32).toString("hex")}/v1`;
	// A direct SDK key is usable only at the address paired with it when the endpoint was issued.
	const directPrefix = `${prefix}/direct-v2/`;
	const directPath = (target: Connection) => directPrefix + createHash("sha256").update(JSON.stringify([target.baseUrl, target.key])).digest("hex");
	const paths = new Map([
		[`${prefix}/responses`, "generate"], [`${prefix}/codex/responses`, "generate"],
		[`${prefix}/responses/compact`, "compact"], [`${prefix}/codex/responses/compact`, "compact"],
		[`${prefix}/v2/codex/responses`, "compact-v2"],
	]);
	const server = Bun.serve({ hostname: "127.0.0.1", port: 0, idleTimeout: 0,
		async fetch(request, listener) {
			const url = new URL(request.url);
			const direct = url.pathname.startsWith(directPrefix);
			const operation = direct ? "compact-v2" : paths.get(url.pathname);
			if (request.method !== "POST" || request.headers.get("host") !== `127.0.0.1:${listener.port}`
				|| request.headers.has("origin") || url.search || !operation) return new Response(null, { status: 403 });
			const key = direct ? request.headers.get("authorization")?.match(/^Bearer (.+)$/i)?.[1] : undefined;
			if (direct && !key) return new Response(null, { status: 403 });
			const options = { signal: request.signal, key };
			let next: Connection;
			try { next = await resolveConnection(options); }
			catch { return new Response("网关或设备授权不可用。", { status: 403 }); }
			if (!next.key || (direct ? next.local || next.selection || url.pathname !== directPath(next) : !next.selection && !next.local)) {
				return new Response(null, { status: 403 });
			}
			let body: BodyInit | null = request.body;
			if (operation === "compact-v2" && !next.local) {
				if (usesClassicResponses(next)) return new Response(null, { status: 501 });
				body = await request.text();
				let payload: unknown;
				try { payload = JSON.parse(body); } catch { return new Response(null, { status: 400 }); }
				const sessionId = isRecord(payload) && wireSession(payload, request.headers);
				if (!isRecord(payload) || typeof payload.model !== "string" || !sessionId ||
					!await supportsRemoteV2(next, payload.model, sessionId, request.signal)) return new Response(null, { status: 501 });
				// A switch or revocation during the GET must not turn its answer into a POST on either target.
				let current: Connection;
				try { current = await resolveConnection(options); } catch { return new Response(null, { status: 403 }); }
				if (current.baseUrl !== next.baseUrl || current.key !== next.key || current.instanceId !== next.instanceId ||
					current.selection !== next.selection || current.local !== next.local) return new Response(null, { status: 409 });
			}
			const classic = usesClassicResponses(next);
			const headers = new Headers({ "content-type": "application/json", authorization: `Bearer ${next.key}` });
			// Never copy the host's bearer, cookies, account/attestation, proxy or arbitrary model headers.
			for (const name of classic ? ["accept"] : nativeHeaders) {
				const value = request.headers.get(name);
				if (value) headers.set(name, value);
			}
			if (operation === "compact-v2") headers.set("x-codex-beta-features", "remote_compaction_v2");
			const endpoint = `${next.baseUrl}${classic ? "" : "/codex"}/responses${operation === "compact" ? "/compact" : ""}`;
			// One immutable address/key pair per HTTP request. Never retry a stream on a replacement target.
			try {
				const upstream = await fetch(endpoint, { method: "POST", body, headers, signal: request.signal, redirect: "error" });
				if (next.selection === "remote" && (upstream.status === 401 || upstream.status === 403)) {
					await upstream.body?.cancel();
					return Response.json({ error: { message: "所选网关拒绝了 OMP 设备 Key。请在 Mac 的 Codexpress 中核对设备授权；扩展不会自动申请新 Key。" } }, { status: upstream.status });
				}
				const responseHeaders = new Headers();
				for (const name of ["content-type", "retry-after", "x-request-id"]) {
					const value = upstream.headers.get(name);
					if (value) responseHeaders.set(name, value);
				}
				return new Response(upstream.body, { status: upstream.status, headers: responseHeaders });
			} catch { return new Response("Codexpress 网关请求未完成。", { status: 502 }); }
		},
	});
	server.unref();
	const origin = `http://127.0.0.1:${server.port}`;
	return { baseUrl: origin + prefix, directV2Endpoint: target => origin + directPath(target), close: () => server.stop(true) };
}
