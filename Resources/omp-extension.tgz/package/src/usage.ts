import { ProviderHttpError } from "@oh-my-pi/pi-ai/error";
import type { UsageLimit, UsageProvider, UsageReport } from "@oh-my-pi/pi-ai/usage";
import type { Connection, ResolveConnection } from "./types";

export interface SourceStatus {
	id: string;
	name: string;
	kind: string;
	enabled: boolean;
	health: string;
	active_requests?: number;
	quota?: {
		stale?: boolean;
		windows?: { name: string; used_percent: number | null; reset_at?: number; window_seconds?: number; ref_cost?: number | null }[];
	};
	balance?: { amount?: number | string | null; currency?: string; estimated?: boolean; stale?: boolean };
	credits?: { available_count?: number | null; stale?: boolean };
}

export interface GatewayStatus {
	running: boolean;
	inflight: number;
	sources: SourceStatus[];
	manual_route?: { id?: string; source_id?: string } | null;
}

type QuotaWindow = NonNullable<NonNullable<SourceStatus["quota"]>["windows"]>[number];
const weekSeconds = 604_800;

export function quotaWindowLabel(window: QuotaWindow): string {
	const scope = window.name.slice(0, Math.max(0, window.name.lastIndexOf(":")));
	const period = window.window_seconds === weekSeconds ? "周额度"
		: window.window_seconds && window.window_seconds > 0 && window.window_seconds < weekSeconds ? "短周期" : undefined;
	if (period) return scope ? `${scope} · ${period}` : period;
	return window.name === "primary" || window.name === "secondary" ? "额度" : window.name;
}

export function quotaReference(source: SourceStatus, window: QuotaWindow, now = Date.now()): {
	text: string; tone: "dim" | "warning" | "error"; below: boolean;
} | undefined {
	if (source.kind !== "official" || window.window_seconds !== weekSeconds) return undefined;
	const reset = window.reset_at;
	const reference = typeof reset === "number" && Number.isFinite(reset) && reset > 0 && reset <= 253402300799
		? Math.max(0, Math.min(100, (reset - now / 1_000) / weekSeconds * 100))
		: typeof window.ref_cost === "number" && Number.isFinite(window.ref_cost) && window.ref_cost >= 0 && window.ref_cost <= 100
			? window.ref_cost : undefined;
	if (reference === undefined) return undefined;
	const remaining = typeof window.used_percent === "number" && Number.isFinite(window.used_percent)
		? Math.max(0, Math.min(100, 100 - window.used_percent)) : undefined;
	const difference = remaining === undefined ? 0 : reference - remaining;
	return {
		text: `ref ${reference.toFixed(1)}%`,
		tone: difference >= 10 ? "error" : difference >= 5 ? "warning" : "dim",
		below: (source.quota?.windows ?? []).some(candidate =>
			!!candidate.window_seconds && candidate.window_seconds > 0 && candidate.window_seconds < weekSeconds),
	};
}

export async function fetchCodexpressStatus(connection: Connection, signal?: AbortSignal): Promise<GatewayStatus> {
	if (connection.selection === "remote") throw new Error("请在 Mac 的 Codexpress 中查看所选远端网关的用量。");
	const response = await fetch(`${connection.baseUrl}/status?include_usage=false`, {
		headers: { Authorization: `Bearer ${connection.key ?? ""}` },
		signal: signal ?? AbortSignal.timeout(10_000),
	});
	if (!response.ok) throw new ProviderHttpError(`Codexpress 状态查询失败（${response.status}）。`, response.status);
	return await response.json() as GatewayStatus;
}

export function createCodexpressUsageProvider(resolveConnection: ResolveConnection): UsageProvider {
	return {
		id: "codexpress",
		cacheVersion: 3,
		supports: params => params.provider === "codexpress" && params.credential.type === "api_key",
		validatesCredentials: true,
		async fetchUsage(params, context): Promise<UsageReport | null> {
			const key = params.credential.apiKey;
			if (!key) return null;
			const connection = await resolveConnection({ key, signal: params.signal });
			if (connection.selection === "remote") return null;
			const response = await context.fetch(`${connection.baseUrl}/status?include_usage=false`, {
				headers: { Authorization: `Bearer ${connection.key ?? key}` }, signal: params.signal,
			});
			if (!response.ok) {
				if (response.status === 401 || response.status === 403) {
					throw new ProviderHttpError("Codexpress Key 已失效，请重新绑定。", response.status);
				}
				return null;
			}
			const snapshot = await response.json() as GatewayStatus;
			const limits: UsageLimit[] = [];
			for (const source of snapshot.sources) {
				const scope = { provider: "codexpress", accountId: source.id };
				for (const window of source.quota?.windows ?? []) {
					if (typeof window.used_percent !== "number" || !Number.isFinite(window.used_percent)) continue;
					const name = quotaWindowLabel(window);
					const reference = quotaReference(source, window);
					limits.push({
						id: `codexpress:${source.id}:quota:${window.name}`, label: `${source.name} · ${name}${reference ? `  ${reference.text}` : ""}`,
						scope: { ...scope, windowId: window.name },
						window: { id: window.name, label: name,
							...(window.window_seconds ? { durationMs: window.window_seconds * 1_000 } : {}),
							...(window.reset_at ? { resetsAt: window.reset_at * 1_000 } : {}) },
						amount: { used: window.used_percent, remaining: Math.max(0, 100 - window.used_percent), unit: "percent" },
						status: window.used_percent >= 100 ? "exhausted" : window.used_percent >= 90 ? "warning" : "ok",
						notes: source.quota?.stale ? ["额度数据待更新"] : undefined,
					});
				}
				const balance = source.balance;
				if (balance?.amount !== undefined && balance.amount !== null) {
					const amount = Number(balance.amount);
					if (Number.isFinite(amount)) limits.push({
						id: `codexpress:${source.id}:balance`, label: `${source.name} · 余额${balance.currency && balance.currency !== "USD" ? `（${balance.currency}）` : ""}`,
						scope, amount: { remaining: amount, unit: balance.currency === "USD" ? "usd" : "unknown" },
						notes: [balance.estimated ? "动态估算余额" : "已核对余额", ...(balance.stale ? ["余额数据待更新"] : [])],
					});
				}
				if (typeof source.credits?.available_count === "number") limits.push({
					id: `codexpress:${source.id}:reset-credits`, label: `${source.name} · 可用重置卡`, scope,
					amount: { remaining: source.credits.available_count, unit: "credits" },
					notes: source.credits.stale ? ["重置卡数据待更新"] : undefined,
				});
			}
			return { provider: "codexpress", fetchedAt: Date.now(), limits, metadata: { endpoint: connection.baseUrl }, raw: snapshot };
		},
	};
}
