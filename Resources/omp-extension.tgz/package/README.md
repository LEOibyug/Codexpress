# Codexpress for OMP

面向官方 OMP 的独立扩展，使用公开的供应商和编辑器接口。0.1.10 起基于 19.0.0 SDK，兼容范围为 OMP 18.16 至 19.x；18.18 与 19.0.0 已验证。供应商功能需要运行中的 Codexpress；键盘选区不依赖网关在线或当前供应商，不需要修改 OMP 核心。

## 安装与本机绑定

在 Codexpress 的「接入 → OMP」点击 **安装扩展**，即可安装应用内置包；安装后重新启动 OMP 再登录。也可以使用发行包 `codexpress-omp-extension-0.1.10.tgz` 的绝对路径手动安装：

```sh
omp plugin install '@codexpress/omp-extension@file:/绝对路径/codexpress-omp-extension-0.1.10.tgz'
omp login codexpress
```

第一次登录会启用 Codexpress 的客户端入口，从本机管理 socket 取得模型 Key 与模型列表。Key 由 OMP 自己的凭据存储保存，不创建 `models.yml`，不修改其他供应商或默认模型。也可在 OMP 的 `/login` 中选择 **Codexpress**。

随后通过 `/model` 选择 `codexpress/模型ID`，或启动：

```sh
omp --model codexpress/gpt-6.1-sol
```

原版 18.16 在扩展加载前验证 `--provider`，因此不要使用 `--provider codexpress`；使用上面的完整模型名。模型 ID 必须存在于你的来源池中。

Codexpress 更换 Key 后重新执行登录。修改端口或模型目录后可执行 `/codexpress connect` 重新绑定并刷新；不要同时加载另一份注册同名供应商的扩展。

## Agent、缓存与压缩

- 直接复用 OMP 的 `openai-codex-responses`：工具、加密推理、原生历史及缓存字段由 OMP 序列化，不转成通用聊天接口。
- 生成通过 `/omp/v1/codex/responses`，V1 压缩通过同级 `/compact`。网关也保留既有 `/omp/v1/responses` 路径。
- 普通请求优先使用本次请求的原生 provider session ID，只有字段缺失时才使用当前会话 ID；advisor 不会被主会话 ID 覆盖。提示缓存键、父会话缓存亲和性与真实线程分开；扩展不重写历史、工具列表或 `prompt_cache_key`。
- 默认启用 V2 原生压缩；结果、错误或明确的不支持均交回 OMP，**压缩方法顺序和降级由 OMP 自己维护**。不注入摘要或关闭 OMP 的压缩链。
- 当前网关不支持 WebSocket，直接使用 HTTP SSE，不进行反复握手。
- 模型能力优先采用网关元数据，其次使用宿主已有模型目录。没有可用容量信息的未知模型沿用 OMP 18.16 的默认客户端预算（128000 上下文、16384 输出），这不是上游实际容量保证。
- 自 Codexpress 0.8.14 与扩展 0.1.7 起，实时同步应用中保存的每模型上下文窗口与固定压缩点。本机绑定和远端 HTTP 模型目录使用相同数据；显式窗口优先于官方标准窗口，未配置时保留标准／最大窗口，由 OMP 的扩展上下文设置选择档位。OMP `models.yml` 中的显式模型覆盖仍优先。
- 固定点通过宿主公开设置接口写为 `compaction.modelThresholds` 下的 `codexpress/模型ID: f600000`，表示精确 600000 Token，而非 600000 的百分比基底。只管理自己添加且未经手动修改的条目；规则更新时同步，撤销或模型移除时清理。手动改写、删除、全局自定义阈值或匹配的模型／通配规则优先，不改其他供应商、压缩开关或方法顺序。

自动条目的所有权记录保存在当前 profile 的 `codexpress-compaction.json`，与连接地址文件分开，避免预算刷新覆盖 IP 修改。旧网关未提供压缩策略字段时沿用最后成功的策略，显式空值表示撤销建议。后台刷新或 `/codexpress connect` 会更新当前模型的预算元数据，不重新选择模型、不清空原生 provider 会话、历史或缓存标识；子代理沿用自己的设置作用域，不向主配置写入临时阈值。

已绑定的会话每 5 秒通过宿主托管计时器读取一次预算版本，即使空闲、没有新提示也会更新窗口和真实压缩点；只有版本变化才重新读取模型目录、注册供应商并同步设置。普通请求前还会检查版本，交互／RPC 输入在宿主处理上一轮失败的压缩恢复前检查，不再等待原来的 60 秒生命周期缓存。探针仅访问本机 `omp.budgets.revision` 或远端 `/omp/v1/budgets/revision`，远端使用现有模型 Key，不需要管理密码；不查询余额、用量或发起模型生成。离线保留最后成功预算，恢复连接后再同步；切换会话替换上下文，关闭会话取消未完成的同步并清理计时器。

该版本只跟踪压缩／上下文预算，不是完整模型目录订阅；其他模型目录变化仍可通过 `/codexpress connect` 主动刷新。旧网关没有预算版本接口时仍可启动和主动刷新，但不支持空闲实时同步。

Codexpress 0.8.17 与扩展 0.1.8 会在本机 profile 的根会话首次就绪时，通过私有 `omp.budgets.migrate` 一次性交接旧版预算归属。只有网关明确声明 `legacy_budget_migration` 能力，且旧快照属于同一 profile、同一配置文件，才接管快照确实跟踪、当前仍与旧应用值相同的 Codexpress 压缩点和窗口字段。旧 `f600000`、`80%` 等阈值先移交至 `codexpress-compaction.json`，再由宿主公开设置接口同步；旧窗口叶子由网关无损清理，扩展用 `modelRegistry.refresh("offline")` 重读本地覆盖，再原地更新当前预算，不拉取上游或重建原生会话。失败或取消可以重试，成功后不在五秒探针中重复迁移。

手动改写或删除的字段、已有扩展归属、其他供应商、`maxTokens`、项目／运行时覆盖、全局自定义阈值和压缩方法顺序保持不变；远端连接、子代理和不同 profile 不执行本机迁移。迁移只表示旧归属已交接或放弃，不保证建议胜过用户设置；之后重新手设为旧值也不会再次接管。没有匹配旧快照或扩展归属记录的条目仍视为用户配置。若压缩点仍不同，请检查这些手动阈值及 `models.yml` 窗口覆盖；旧网关没有迁移能力时继续原有同步，不声称已迁移。

预算加载成功后，若当前 Codexpress 模型实际使用的窗口或压缩点与网关明确提供的数值不同，扩展会通知当前值、Codexpress 设置值和 OMP 设置优先的原因；相同差异不重复提醒。提示使用宿主实际预算计算，不修改或删除任何用户覆盖。

缓存命中以真实上游返回的 Token 计数为准；本机原文缓存不代表上游缓存。安装扩展本身不保证某个供应商的命中率。

### 官方来源的工作区缓存分组

Codexpress 0.8.5 与扩展 0.1.3 默认按 **OMP 配置档案 + 工作目录** 生成不透明缓存分组。同一工作区的新会话可共享稳定前缀；真实会话、advisor、线程、历史和来源绑定仍然独立。网关只在官方来源的出站副本中设置共享的 `session-id`，按账号、模型与速度档位隔离；`session_id`、`conversation_id`、原生元数据及正文 `prompt_cache_key` 不改写，API／Clauder 来源也不改写缓存头。

需要跨工作目录指定分组时，使用原版 OMP 18.18 的显式 Key；同一配置档案内相同 Key 优先于工作目录：

```sh
omp --model codexpress/gpt-6.1-sol --prompt-cache-key codexpress-my-project
```

关闭 OMP 提示缓存或传入空 Key，会关闭这层共享亲和性，并清除该真实会话的压缩分组关联；不代表上游服务停止所有自动缓存。V1／V2 压缩从普通请求的真实会话继承分组，不把父级缓存头当作子会话。关联仅保存在网关内存，最多 4096 条；重启后由普通请求重新建立。

命中率仍以实际上游的缓存 Token 计数为准。比较时固定账号、模型和速度，将首次请求、压缩后首轮与热续接分开统计。扩展不添加 `prompt_cache_options`、显式缓存断点或更长 TTL，不删历史、冻结动态提示或填充无用 Token。

### 稳定历史前缀（按需）

OMP 的工具结果裁剪会改变旧前缀。若更重视缓存稳定性，可在专用配置档案中关闭以下两项：

```yaml
compaction:
  supersedeReads: false
  dropUseless: false
```

这些是整个配置档案的设置，不是 Codexpress 专属开关；会保留更多旧工具输出，增大输入并可能更早触发压缩。扩展不自动修改它们，也不恢复已被裁剪的历史或关闭正常压缩。


## 原生绘图

在 OMP 设置中启用 `generate_image.enabled: true`。通过相同的 Codexpress 登录使用 OMP 内置 `generate_image`，无需另一套图片 Key 或工具。

网关提供可用的 `gpt-image-2` 图片模型，OMP 使用同供应商聊天模型作为 Responses 载体。支持文生图、参考图编辑，以及 OMP 原生工具使用的 PNG／WebP 返回。需要在 Codexpress 中启用图片生成，并有可用的官方账号；账号选择、代理与图片并发继续由网关管理，不使用普通聊天的来源调度。

## 用量与管理

`/usage` 或 `omp usage --provider codexpress --json` 展示逐来源额度、动态余额及重置卡；不对上游发起刷新。没有短周期额度时不显示该项；查询临时失败由 OMP 保留最后成功的数据，认证失败则要求重新绑定。账户余额不是单次请求费用，网关的账单核对结果以 Codexpress 统计为准。

扩展 0.1.5 显示官方来源七天窗口（`window_seconds: 604800`）的 `ref_cost`，标签为 `ref 42.3%`：这是**本周期剩余时间的比例**，不是费用或可消费额度。按 `(重置时间 − 当前时间) / 七天 × 100%` 在本地倒计，缺少有效重置时间时仅采用有效的参考值，否则不显示。值限制在 0–100%，周期开始为 100%，到期保持 0% 等待新快照，不推算下一周期。不新增额度条、不改变真实已用／剩余额度、计费或路由，也不增加上游请求。

原版 OMP `/usage` 概览和详情、`omp usage --provider codexpress` 均通过公开 `UsageLimit.label` 在周额度标签中显示 `ref`，JSON 输出同样保留。参考值遵循 OMP 用量报告的快照缓存；不添加虚构额度或重复的 notes。宿主固定了标签字体、布局和颜色，所以标准 `/usage` 不能按短周期情况将 ref 换行或单独着色；扩展不接管 `/usage` 或修改宿主核心，完整样式由下述状态面板提供。

完整布局请打开 `/codexpress status`：来源没有真实更短窗口时 ref 与周额度并排；有更短窗口时 ref 在周额度下方小字显示。只有 ref 文字着色：`ref_cost - clamp(100 - used_percent, 0, 100)` 达到 5 个百分点为黄色，达到 10 个百分点为红色，否则使用次要文字色；真实剩余额度未知时仍使用次要文字色。周额度本身不随 ref 改色。面板中的 ref 每分钟按本地时钟推进，其他额度保持本次快照；可用方向键／翻页键滚动，Enter／Esc 关闭。重新打开读取新状态，不主动刷新上游。

`/codexpress` 打开操作菜单，也可直接输入：

| 命令 | 操作 |
| --- | --- |
| `/codexpress status` | 查看来源状态、余额、额度与请求活动 |
| `/codexpress connect` | 重新绑定并刷新模型 |
| `/codexpress takeover 来源ID` | 抢占指定来源 |
| `/codexpress cancel` | 停止当前抢占 |
| `/codexpress recover 来源ID` | 恢复来源 |
| `/codexpress balances [来源ID]` | 主动更新余额 |
| `/codexpress quotas [来源ID]` | 主动更新官方额度与卡片 |
| `/codexpress billing [来源ID]` | 主动核对账单 |
| `/codexpress reset 来源ID` | 提交重置请求，在 Codexpress 窗口确认后才消耗卡片 |

交互模式中省略抢占、恢复或重置的来源会出现选择菜单；也可填写唯一来源名称，同名时使用 ID 区分。状态与管理结果不注入模型上下文。

## 键盘选区

安装扩展后，交互式输入框自动支持键盘选区，保留现有编辑器扩展、补全、历史与附件处理；不接管鼠标。

| 快捷键 | 操作 |
| --- | --- |
| Shift + ← / → | 按字素扩展选区，中文、组合字符与 emoji 保持完整 |
| Ctrl / Alt + Shift + ← / → | 按词扩展选区 |
| Shift + ↑ / ↓ | 按实际折行扩展选区 |
| Shift + Home / End | 选择到当前行首 / 行尾 |
| ⌘A（终端传递该按键时） | 全选当前草稿 |
| ⌘X（终端传递该按键时） | 将选区剪切到剪贴板；没有选区时不剪切 |

Backspace / Delete 删除选区，直接键入替换选区；Escape 取消，普通左右方向键收拢到选区边界。Ctrl+A 仍是行首，不改成全选。撤销使用 OMP 原生 `Ctrl+_` / `Ctrl+-`。

扩展 0.1.9 起，剪切通过 OMP 原生剪贴板回调传递选中文本，再删除选区；本机剪贴板及 SSH 的 OSC 52 传输由宿主处理。剪切、删除与键入替换可单步撤销。粘贴替换继续使用宿主的折叠粘贴、附件存储与菜单，分为“删除选区”和“插入粘贴”两个原生撤销步骤；不复制或改写宿主私有撤销栈。非交互式、RPC 和子代理不改变编辑器。

## 远端与配置档案

本机默认读取 `~/Library/Application Support/Codexpress/control.sock`。可通过 `CODEXPRESS_STATE_DIR` 指定其他状态目录。扩展配置使用 OMP 当前 profile 的 Agent 目录，支持 `PI_CODING_AGENT_DIR`。

在 Codexpress 的「接入 → 远端 SSH」选择 **OMP**，填写连接、远端 Agent 目录以及远端可访问的 Mac IP／主机名，点击 **安装扩展并连接**。应用传输内置包，调用远端原生插件安装与登录；全新目录也可使用。安装后重启 OMP，在 `/model` 中选择 Codexpress 模型，不需要自定义 OMP 或手工编辑 YAML。远端扩展需更新至 0.1.7，且本机 Codexpress 至少为 0.8.14，才能在空闲时实时同步模型预算。

IP 或客户端端口变化后，点击 **更新连接地址**，无需重装。正在运行的 OMP 在下一轮请求读取新配置；默认普通请求及 V1／V2 压缩地址随之更新，显式自定义端点、启用开关、原生凭据、会话和缓存标识保持不变。该检查不反复拉取模型目录。远端设置的 `CODEXPRESS_BASE_URL` 优先于配置文件，需自行同步修改；应用会提示，不改 shell 配置。

也可以手动设置远端连接：

```sh
export CODEXPRESS_BASE_URL='http://可访问的Mac地址:17865/omp/v1'
export CODEXPRESS_API_KEY='Codexpress客户端Key'
omp login codexpress
```

也可以在当前 OMP Agent 目录的 `codexpress.json` 保存非密钥配置：

```json
{ "baseUrl": "http://可访问的Mac地址:17865/omp/v1" }
```

登录时填写 Key，由 OMP 保存。远端不使用本机回环地址；网络应能访问 Codexpress 的客户端端口。

远端管理操作另外需要 `CODEXPRESS_MANAGEMENT_BASE_URL`（含 `/v1`）与 `CODEXPRESS_MANAGEMENT_API_KEY`。管理 API 仍只监听 Codexpress 本机，远端须通过自己的 SSH 隧道访问；客户端 Key 与管理 Key 不混用。本机管理使用原有 Unix socket，不要求打开管理 HTTP 服务。

## 从源码构建

需要 Bun 1.4.4 或更新版本。从发行包解包重建时，先将 `dist/sdk.lock` 复制为根目录的 `bun.lock`；这是开发锁文件的原样副本，用于避开包管理器对根锁文件的自动排除。

```sh
bun install --frozen-lockfile --ignore-scripts
bun run check
bun test
bun run pack
```

发行包附带源码、测试、构建脚本和锁文件，可解包后按上述命令重建；不包含开发依赖或运行数据。运行时只加载 `dist/index.mjs`，宿主 SDK 由 OMP 提供，不把另一份 OMP 打进包。开发时可 `omp plugin link /绝对路径/codexpress-omp-extension`；正式安装请使用打包后的 tgz，以免运行依赖源码目录。
